#!/bin/bash
# ============================================
#   bltzTeams - Auto Build Script for Replit
# ============================================

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}==============================${NC}"
echo -e "${GREEN}   bltzTeams Auto Builder     ${NC}"
echo -e "${GREEN}==============================${NC}"

# Bước 1: Cài Maven nếu chưa có
echo -e "\n${YELLOW}[1/5] Kiểm tra Maven...${NC}"
if ! command -v mvn &> /dev/null; then
    echo "Đang cài Maven..."
    apt-get install -y maven -q
    if ! command -v mvn &> /dev/null; then
        echo -e "${RED}Lỗi: Không cài được Maven!${NC}"
        exit 1
    fi
fi
echo -e "${GREEN}Maven OK!${NC}"

# Bước 2: Tải Spigot API
echo -e "\n${YELLOW}[2/5] Tải Spigot API 1.20.1...${NC}"
SPIGOT_JAR="spigot-api.jar"

check_jar() {
    [ -f "$1" ] && [ $(stat -c%s "$1" 2>/dev/null || echo 0) -gt 1000000 ]
}

if ! check_jar "$SPIGOT_JAR"; then
    rm -f "$SPIGOT_JAR"
    URLS=(
        "https://hub.spigotmc.org/nexus/content/repositories/snapshots/org/spigotmc/spigot-api/1.20.1-R0.1-SNAPSHOT/spigot-api-1.20.1-R0.1-20230608.195247-54.jar"
        "https://repo.papermc.io/repository/maven-public/org/spigotmc/spigot-api/1.20.1-R0.1-SNAPSHOT/spigot-api-1.20.1-R0.1-SNAPSHOT.jar"
    )
    for url in "${URLS[@]}"; do
        echo "Thử: $url"
        curl -L --max-time 60 -o "$SPIGOT_JAR" "$url" 2>&1
        check_jar "$SPIGOT_JAR" && break
        rm -f "$SPIGOT_JAR"
    done
fi

if ! check_jar "$SPIGOT_JAR"; then
    echo -e "${RED}Lỗi: Không tải được Spigot API!${NC}"
    echo "Tải thủ công tại: https://hub.spigotmc.org/nexus/content/repositories/snapshots/org/spigotmc/spigot-api/1.20.1-R0.1-SNAPSHOT/"
    echo "Đặt vào thư mục này và đổi tên thành: spigot-api.jar"
    exit 1
fi
echo -e "${GREEN}Spigot API OK! ($(du -h $SPIGOT_JAR | cut -f1))${NC}"

# Bước 3: Cài Spigot vào Maven local repo
echo -e "\n${YELLOW}[3/5] Đăng ký Spigot API vào Maven...${NC}"
mvn install:install-file \
    -Dfile="$SPIGOT_JAR" \
    -DgroupId=org.spigotmc \
    -DartifactId=spigot-api \
    -Dversion=1.20.1-R0.1-SNAPSHOT \
    -Dpackaging=jar \
    -q

if [ $? -ne 0 ]; then
    echo -e "${RED}Lỗi: Không đăng ký được Spigot API!${NC}"
    exit 1
fi
echo -e "${GREEN}Đăng ký xong!${NC}"

# Bước 4: Tải PlaceholderAPI (optional)
echo -e "\n${YELLOW}[4/5] Tải PlaceholderAPI (optional)...${NC}"
PAPI_JAR="placeholderapi.jar"
if ! check_jar "$PAPI_JAR"; then
    rm -f "$PAPI_JAR"
    curl -L --max-time 60 -o "$PAPI_JAR" \
        "https://repo.extendedclip.com/content/repositories/placeholderapi/me/clip/placeholderapi/2.11.5/placeholderapi-2.11.5.jar" 2>&1
fi

if check_jar "$PAPI_JAR"; then
    mvn install:install-file \
        -Dfile="$PAPI_JAR" \
        -DgroupId=me.clip \
        -DartifactId=placeholderapi \
        -Dversion=2.11.5 \
        -Dpackaging=jar \
        -q 2>&1
    echo -e "${GREEN}PlaceholderAPI OK!${NC}"
else
    echo -e "${YELLOW}Bỏ qua PlaceholderAPI (không bắt buộc)${NC}"
    rm -f "$PAPI_JAR"
fi

# Bước 5: Build plugin
echo -e "\n${YELLOW}[5/5] Đang build bltzTeams...${NC}"
mvn package -DskipTests 2>&1

if [ $? -eq 0 ]; then
    JAR_FILE=$(find target -name "bltzTeams-*.jar" ! -name "*original*" | head -1)
    echo -e "\n${GREEN}==============================${NC}"
    echo -e "${GREEN}   BUILD THÀNH CÔNG!          ${NC}"
    echo -e "${GREEN}==============================${NC}"
    echo -e "File jar: ${YELLOW}$JAR_FILE${NC}"
    echo -e "Download file đó bỏ vào folder plugins của server là xong!"
else
    echo -e "\n${RED}==============================${NC}"
    echo -e "${RED}   BUILD THẤT BẠI!            ${NC}"
    echo -e "${RED}==============================${NC}"
    echo "Xem lỗi ở trên và liên hệ bltz để được hỗ trợ."
fi
