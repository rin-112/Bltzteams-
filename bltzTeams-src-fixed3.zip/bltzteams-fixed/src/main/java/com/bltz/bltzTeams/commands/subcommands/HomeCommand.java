package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HomeCommand extends SubCommand {

    private final Map<UUID, Location> startLocations = new HashMap<>();

    public HomeCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "home"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_TELEPORT)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (team.getHome() == null) {
            msg.send(player, msg.getRaw("no-home-set"));
            plugin.getSoundManager().playError(player);
            return;
        }

        int delay = plugin.getConfigUtils().getTeleportDelay();
        Location startLoc = player.getLocation();
        startLocations.put(player.getUniqueId(), startLoc);

        new BukkitRunnable() {
            int remaining = delay;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    startLocations.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                Location current = player.getLocation();
                Location start = startLocations.get(player.getUniqueId());
                if (start != null && (Math.abs(current.getX() - start.getX()) > 0.5 ||
                        Math.abs(current.getY() - start.getY()) > 0.5 ||
                        Math.abs(current.getZ() - start.getZ()) > 0.5)) {
                    msg.send(player, msg.getRaw("teleport-cancelled"));
                    startLocations.remove(player.getUniqueId());
                    cancel();
                    return;
                }
                if (remaining <= 0) {
                    player.teleport(team.getHome());
                    msg.sendMsg(player, "teleport-success");
                    plugin.getSoundManager().playTeleportSuccess(player);
                    startLocations.remove(player.getUniqueId());
                    cancel();
                } else {
                    msg.send(player, msg.getRaw("teleporting", "%seconds%", String.valueOf(remaining)));
                    plugin.getSoundManager().playTeleportCountdown(player);
                    remaining--;
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}
