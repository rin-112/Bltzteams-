package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;

public class RenameCommand extends SubCommand {

    public RenameCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "rename"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-rename"));
            return;
        }

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_RENAME)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        String newName = args[0];
        int min = plugin.getConfigUtils().getNameMinLength();
        int max = plugin.getConfigUtils().getNameMaxLength();

        if (newName.length() < min || newName.length() > max) {
            msg.send(player, msg.getRaw("team-name-invalid-length",
                    "%min%", String.valueOf(min), "%max%", String.valueOf(max)));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!newName.matches("[a-zA-Z0-9_]+")) {
            msg.send(player, msg.getRaw("team-name-invalid-chars"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!tm.renameTeam(team, newName)) {
            msg.send(player, msg.getRaw("rename-name-exists"));
            plugin.getSoundManager().playError(player);
            return;
        }

        msg.sendMsg(player, "rename-success", "%team%", newName);
        plugin.getSoundManager().playSuccess(player);
    }
}
