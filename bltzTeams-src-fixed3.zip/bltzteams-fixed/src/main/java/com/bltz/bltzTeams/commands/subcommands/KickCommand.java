package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.UUID;

public class KickCommand extends SubCommand {

    public KickCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "kick"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-kick"));
            return;
        }

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_INVITE)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        // Find target
        UUID targetId = null;
        String targetName = args[0];
        for (UUID memberId : team.getMembers()) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(memberId);
            if (op.getName() != null && op.getName().equalsIgnoreCase(targetName)) {
                targetId = memberId;
                break;
            }
        }

        if (targetId == null) {
            msg.send(player, msg.getRaw("player-not-in-team", "%player%", targetName));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (team.isOwner(targetId)) {
            msg.send(player, msg.getRaw("cannot-kick-owner"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (targetId.equals(player.getUniqueId())) {
            msg.send(player, msg.getRaw("cannot-edit-own-permissions"));
            plugin.getSoundManager().playError(player);
            return;
        }

        plugin.getChatManager().disableTeamChat(targetId);
        tm.removeMember(team, targetId);

        msg.sendMsg(player, "player-kicked", "%player%", targetName);
        plugin.getSoundManager().playTeamKick(player);

        Player target = Bukkit.getPlayer(targetId);
        if (target != null) {
            msg.send(target, msg.getRaw("kicked", "%team%", team.getName()));
            plugin.getSoundManager().playTeamKick(target);
        }
    }
}
