package com.bltz.bltzTeams.managers;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.database.DatabaseProvider;
import com.bltz.bltzTeams.models.Team;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TeamManager {

    private final BltzTeams plugin;
    private final DatabaseProvider db;

    // In-memory cache
    private final Map<UUID, Team> teamsById = new ConcurrentHashMap<>();
    private final Map<String, UUID> teamsByName = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> playerToTeam = new ConcurrentHashMap<>();

    public TeamManager(BltzTeams plugin, DatabaseProvider db) {
        this.plugin = plugin;
        this.db = db;
        loadAll();
    }

    public void loadAll() {
        teamsById.clear();
        teamsByName.clear();
        playerToTeam.clear();
        for (Team team : db.loadAllTeams()) {
            teamsById.put(team.getTeamId(), team);
            teamsByName.put(team.getName().toLowerCase(), team.getTeamId());
            for (UUID memberId : team.getMembers()) {
                playerToTeam.put(memberId, team.getTeamId());
            }
        }
    }

    public Team getTeamByPlayer(UUID playerId) {
        UUID teamId = playerToTeam.get(playerId);
        if (teamId == null) return null;
        return teamsById.get(teamId);
    }

    public Team getTeamByName(String name) {
        UUID teamId = teamsByName.get(name.toLowerCase());
        if (teamId == null) return null;
        return teamsById.get(teamId);
    }

    public Team getTeamById(UUID teamId) {
        return teamsById.get(teamId);
    }

    public Collection<Team> getAllTeams() {
        return Collections.unmodifiableCollection(teamsById.values());
    }

    public Team createTeam(String name, UUID ownerId) {
        Team team = new Team(UUID.randomUUID(), name, ownerId);
        teamsById.put(team.getTeamId(), team);
        teamsByName.put(name.toLowerCase(), team.getTeamId());
        playerToTeam.put(ownerId, team.getTeamId());
        db.saveTeam(team);
        return team;
    }

    public void disbandTeam(Team team) {
        for (UUID memberId : new ArrayList<>(team.getMembers())) {
            playerToTeam.remove(memberId);
        }
        teamsByName.remove(team.getName().toLowerCase());
        teamsById.remove(team.getTeamId());

        // Remove from ally lists
        for (Team other : teamsById.values()) {
            other.getAllies().remove(team.getTeamId());
            other.getPendingAllyRequests().remove(team.getTeamId());
            saveTeam(other);
        }

        db.deleteTeam(team.getTeamId());
    }

    public void addMember(Team team, UUID playerId) {
        team.addMember(playerId);
        playerToTeam.put(playerId, team.getTeamId());
        db.saveTeam(team);
    }

    public void removeMember(Team team, UUID playerId) {
        team.removeMember(playerId);
        playerToTeam.remove(playerId);
        db.saveTeam(team);
    }

    public void saveTeam(Team team) {
        db.saveTeam(team);
    }

    public boolean renameTeam(Team team, String newName) {
        if (teamsByName.containsKey(newName.toLowerCase())) return false;
        teamsByName.remove(team.getName().toLowerCase());
        team.setName(newName);
        teamsByName.put(newName.toLowerCase(), team.getTeamId());
        db.saveTeam(team);
        return true;
    }

    public boolean isInTeam(UUID playerId) {
        return playerToTeam.containsKey(playerId);
    }

    public boolean teamExists(String name) {
        return teamsByName.containsKey(name.toLowerCase());
    }

    public boolean addAlly(Team team1, Team team2) {
        if (team1.getAllies().size() >= 9 || team2.getAllies().size() >= 9) return false;
        team1.addAlly(team2.getTeamId());
        team2.addAlly(team1.getTeamId());
        // Remove any pending requests
        db.removeAllyRequest(team1.getTeamId(), team2.getTeamId());
        db.removeAllyRequest(team2.getTeamId(), team1.getTeamId());
        db.saveTeam(team1);
        db.saveTeam(team2);
        return true;
    }

    public void removeAlly(Team team1, Team team2) {
        team1.removeAlly(team2.getTeamId());
        team2.removeAlly(team1.getTeamId());
        db.saveTeam(team1);
        db.saveTeam(team2);
    }

    public boolean areAllies(UUID teamId1, UUID teamId2) {
        Team t1 = teamsById.get(teamId1);
        if (t1 == null) return false;
        return t1.isAlly(teamId2);
    }

    public DatabaseProvider getDb() { return db; }
}
