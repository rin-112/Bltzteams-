package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
public class AdminDeleteCommand extends AdminSubCommand {
    public AdminDeleteCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "delete"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-delete")); return; }
        Team team = plugin.getTeamManager().getTeamByName(args[0]);
        if (team == null) { msg.send(player, msg.getRaw("team-not-found", "%team%", args[0])); return; }
        // Notify members
        for (java.util.UUID memberId : team.getMembers()) {
            Player member = Bukkit.getPlayer(memberId);
            if (member != null) msg.send(member, msg.getRaw("team-disbanded", "%team%", team.getName()));
        }
        plugin.getTeamManager().disbandTeam(team);
        msg.sendMsg(player, "admin-delete-success", "%team%", args[0]);
    }
}
