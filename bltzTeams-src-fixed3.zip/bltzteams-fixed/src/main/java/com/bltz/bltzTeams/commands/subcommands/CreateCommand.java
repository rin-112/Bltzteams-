package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;

public class CreateCommand extends SubCommand {

    public CreateCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "create"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-create"));
            return;
        }

        if (tm.isInTeam(player.getUniqueId())) {
            msg.send(player, msg.getRaw("already-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        String name = args[0];
        int min = plugin.getConfigUtils().getNameMinLength();
        int max = plugin.getConfigUtils().getNameMaxLength();

        if (name.length() < min || name.length() > max) {
            msg.send(player, msg.getRaw("team-name-invalid-length",
                    "%min%", String.valueOf(min), "%max%", String.valueOf(max)));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!name.matches("[a-zA-Z0-9_]+")) {
            msg.send(player, msg.getRaw("team-name-invalid-chars"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (tm.teamExists(name)) {
            msg.send(player, msg.getRaw("rename-name-exists"));
            plugin.getSoundManager().playError(player);
            return;
        }

        tm.createTeam(name, player.getUniqueId());
        msg.sendMsg(player, "team-created", "%team%", name);
        plugin.getSoundManager().playTeamCreate(player);
    }
}
