package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;
public class AdminReloadCommand extends AdminSubCommand {
    public AdminReloadCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "reload"; }
    @Override
    public void execute(Player player, String[] args) {
        plugin.reloadPlugin();
        plugin.getMessageUtils().send(player, plugin.getMessageUtils().getRaw("reload-success"));
    }
}
