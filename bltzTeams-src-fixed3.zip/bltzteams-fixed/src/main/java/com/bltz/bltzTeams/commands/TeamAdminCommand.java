package com.bltz.bltzTeams.commands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.adminsubcommands.*;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class TeamAdminCommand implements CommandExecutor, TabCompleter {

    private final BltzTeams plugin;
    private final Map<String, AdminSubCommand> subCommands = new LinkedHashMap<>();

    public TeamAdminCommand(BltzTeams plugin) {
        this.plugin = plugin;
        register(new AdminHomeCommand(plugin));
        register(new AdminSetHomeCommand(plugin));
        register(new AdminDelHomeCommand(plugin));
        register(new AdminDeleteCommand(plugin));
        register(new AdminJoinCommand(plugin));
        register(new AdminLeaveCommand(plugin));
        register(new AdminReloadCommand(plugin));
        register(new AdminChatSpyCommand(plugin));
        register(new AdminPurgeCommand(plugin));
    }

    private void register(AdminSubCommand cmd) {
        subCommands.put(cmd.getName().toLowerCase(), cmd);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageUtils().getRaw("only-player-command"));
            return true;
        }

        if (!player.hasPermission("hnybteams.admin")) {
            player.sendMessage(plugin.getMessageUtils().getRaw("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendAdminHelp(player);
            return true;
        }

        String subName = args[0].toLowerCase();
        AdminSubCommand sub = subCommands.get(subName);
        if (sub == null) {
            sendAdminHelp(player);
            return true;
        }

        sub.execute(player, Arrays.copyOfRange(args, 1, args.length));
        return true;
    }

    private void sendAdminHelp(Player player) {
        MessageUtils msg = plugin.getMessageUtils();
        msg.send(player, "&b&lBltzTeams Admin Commands");
        for (String name : subCommands.keySet()) {
            msg.send(player, "&e/teamad " + name + " &7- Admin command");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> list = new ArrayList<>(subCommands.keySet());
            list.removeIf(s -> !s.startsWith(args[0].toLowerCase()));
            return list;
        }
        return List.of();
    }
}
