package com.bltz.bltzTeams.models;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;

import java.util.*;

public class Team {

    private final UUID teamId;
    private String name;
    private String displayName;
    private UUID ownerId;
    private final List<UUID> members;
    private Location home;
    private boolean pvpEnabled;
    private final long createdAt;

    // Member permissions: UUID -> boolean[] {echest, homes, invite, pvp, teleport, chat, rename, setdisplayname, manageally, managemembers}
    private final Map<UUID, boolean[]> memberPermissions;

    // Ally data: UUID -> pvpEnabled with that ally
    private final Map<UUID, Boolean> allies;

    // Pending ally requests (this team sent to others or others sent to this team)
    private final Set<UUID> pendingAllyRequests; // teams this team has sent requests to

    public static final int PERM_ECHEST = 0;
    public static final int PERM_HOMES = 1;
    public static final int PERM_INVITE = 2;
    public static final int PERM_PVP = 3;
    public static final int PERM_TELEPORT = 4;
    public static final int PERM_CHAT = 5;
    public static final int PERM_RENAME = 6;
    public static final int PERM_SETDISPLAYNAME = 7;
    public static final int PERM_MANAGEALLY = 8;
    public static final int PERM_MANAGEMEMBERS = 9;
    public static final int PERM_COUNT = 10;

    public Team(UUID teamId, String name, UUID ownerId) {
        this.teamId = teamId;
        this.name = name;
        this.displayName = name;
        this.ownerId = ownerId;
        this.members = new ArrayList<>();
        this.members.add(ownerId);
        this.pvpEnabled = false;
        this.createdAt = System.currentTimeMillis();
        this.memberPermissions = new HashMap<>();
        this.allies = new HashMap<>();
        this.pendingAllyRequests = new HashSet<>();
        // Init owner with all permissions
        boolean[] ownerPerms = new boolean[PERM_COUNT];
        Arrays.fill(ownerPerms, true);
        this.memberPermissions.put(ownerId, ownerPerms);
    }

    public Team(UUID teamId, String name, String displayName, UUID ownerId,
                List<UUID> members, Location home, boolean pvpEnabled, long createdAt,
                Map<UUID, boolean[]> memberPermissions, Map<UUID, Boolean> allies,
                Set<UUID> pendingAllyRequests) {
        this.teamId = teamId;
        this.name = name;
        this.displayName = displayName;
        this.ownerId = ownerId;
        this.members = members;
        this.home = home;
        this.pvpEnabled = pvpEnabled;
        this.createdAt = createdAt;
        this.memberPermissions = memberPermissions;
        this.allies = allies;
        this.pendingAllyRequests = pendingAllyRequests;
    }

    public UUID getTeamId() { return teamId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public UUID getOwnerId() { return ownerId; }
    public void setOwnerId(UUID ownerId) { this.ownerId = ownerId; }
    public List<UUID> getMembers() { return members; }
    public Location getHome() { return home; }
    public void setHome(Location home) { this.home = home; }
    public boolean isPvpEnabled() { return pvpEnabled; }
    public void setPvpEnabled(boolean pvpEnabled) { this.pvpEnabled = pvpEnabled; }
    public long getCreatedAt() { return createdAt; }
    public Map<UUID, boolean[]> getMemberPermissions() { return memberPermissions; }
    public Map<UUID, Boolean> getAllies() { return allies; }
    public Set<UUID> getPendingAllyRequests() { return pendingAllyRequests; }

    public boolean hasMember(UUID uuid) {
        return members.contains(uuid);
    }

    public boolean isOwner(UUID uuid) {
        return ownerId.equals(uuid);
    }

    public void addMember(UUID uuid) {
        if (!members.contains(uuid)) {
            members.add(uuid);
            // Default permissions: all false except echest, teleport, chat
            boolean[] perms = new boolean[PERM_COUNT];
            perms[PERM_ECHEST] = true;
            perms[PERM_TELEPORT] = true;
            perms[PERM_CHAT] = true;
            memberPermissions.put(uuid, perms);
        }
    }

    public void removeMember(UUID uuid) {
        members.remove(uuid);
        memberPermissions.remove(uuid);
    }

    public boolean hasPerm(UUID uuid, int perm) {
        if (isOwner(uuid)) return true;
        boolean[] perms = memberPermissions.get(uuid);
        if (perms == null) return false;
        return perms[perm];
    }

    public void setPerm(UUID uuid, int perm, boolean value) {
        memberPermissions.computeIfAbsent(uuid, k -> new boolean[PERM_COUNT]);
        memberPermissions.get(uuid)[perm] = value;
    }

    public boolean[] getPerms(UUID uuid) {
        if (isOwner(uuid)) {
            boolean[] all = new boolean[PERM_COUNT];
            Arrays.fill(all, true);
            return all;
        }
        return memberPermissions.getOrDefault(uuid, new boolean[PERM_COUNT]);
    }

    public boolean isAlly(UUID otherTeamId) {
        return allies.containsKey(otherTeamId);
    }

    public boolean allyPvpEnabled(UUID otherTeamId) {
        return allies.getOrDefault(otherTeamId, false);
    }

    public void addAlly(UUID otherTeamId) {
        allies.put(otherTeamId, false); // default: no pvp with ally
    }

    public void removeAlly(UUID otherTeamId) {
        allies.remove(otherTeamId);
    }

    public void setAllyPvp(UUID otherTeamId, boolean enabled) {
        if (allies.containsKey(otherTeamId)) {
            allies.put(otherTeamId, enabled);
        }
    }

    public int getMemberCount() { return members.size(); }

    public String getOwnerName() {
        OfflinePlayer p = Bukkit.getOfflinePlayer(ownerId);
        return p.getName() != null ? p.getName() : ownerId.toString().substring(0, 8);
    }
}
