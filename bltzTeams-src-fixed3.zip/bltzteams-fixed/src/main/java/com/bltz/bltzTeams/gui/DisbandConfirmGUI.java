package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class DisbandConfirmGUI {

    private final BltzTeams plugin;
    private final Player player;
    private final Team team;

    public DisbandConfirmGUI(BltzTeams plugin, Player player, Team team) {
        this.plugin = plugin;
        this.player = player;
        this.team = team;
    }

    public void open() {
        String title = MessageUtils.colorize(
                plugin.getConfig().getString("gui.disband-gui.title", "&cConfirm Disband Team"));
        Inventory inv = Bukkit.createInventory(new DisbandGUIHolder(), 27, title);

        // Fill
        ItemStack fill = GUIItemBuilder.fillItem(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 0; i < 27; i++) inv.setItem(i, fill);

        int cancelSlot = plugin.getConfig().getInt("gui.disband-gui.items.cancel.slot", 11);
        int confirmSlot = plugin.getConfig().getInt("gui.disband-gui.items.confirm.slot", 15);

        inv.setItem(cancelSlot, new GUIItemBuilder(Material.RED_STAINED_GLASS_PANE)
                .name(plugin.getConfig().getString("gui.disband-gui.items.cancel.name", "&cCancel"))
                .lore(plugin.getConfig().getStringList("gui.disband-gui.items.cancel.lore")).build());

        inv.setItem(confirmSlot, new GUIItemBuilder(Material.LIME_STAINED_GLASS_PANE)
                .name(plugin.getConfig().getString("gui.disband-gui.items.confirm.name", "&aConfirm"))
                .lore(plugin.getConfig().getStringList("gui.disband-gui.items.confirm.lore")).build());

        player.openInventory(inv);
    }

    public Team getTeam() { return team; }
}
