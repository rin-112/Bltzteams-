package com.bltz.bltzTeams.managers;

import java.util.*;

public class InviteManager {

    // playerId -> set of team IDs they're invited to
    private final Map<UUID, Set<UUID>> invites = new HashMap<>();

    public boolean hasInvite(UUID playerId, UUID teamId) {
        Set<UUID> set = invites.get(playerId);
        return set != null && set.contains(teamId);
    }

    public void addInvite(UUID playerId, UUID teamId) {
        invites.computeIfAbsent(playerId, k -> new HashSet<>()).add(teamId);
    }

    public void removeInvite(UUID playerId, UUID teamId) {
        Set<UUID> set = invites.get(playerId);
        if (set != null) set.remove(teamId);
    }

    public void clearInvites(UUID playerId) {
        invites.remove(playerId);
    }
}
