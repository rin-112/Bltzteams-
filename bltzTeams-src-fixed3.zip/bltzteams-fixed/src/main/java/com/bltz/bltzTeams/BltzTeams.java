package com.bltz.bltzTeams;

import com.bltz.bltzTeams.commands.TeamAdminCommand;
import com.bltz.bltzTeams.commands.TeamCommand;
import com.bltz.bltzTeams.database.DatabaseProvider;
import com.bltz.bltzTeams.database.H2DatabaseProvider;
import com.bltz.bltzTeams.database.YamlDatabaseProvider;
import com.bltz.bltzTeams.gui.TeamGUI;
import com.bltz.bltzTeams.listeners.TeamCrystalListener;
import com.bltz.bltzTeams.listeners.TeamEchestListener;
import com.bltz.bltzTeams.listeners.TeamListener;
import com.bltz.bltzTeams.managers.*;
import com.bltz.bltzTeams.placeholders.TeamPlaceholders;
import com.bltz.bltzTeams.utils.ConfigUtils;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Logger;

public class BltzTeams extends JavaPlugin {

    private static BltzTeams instance;

    private DatabaseProvider databaseProvider;
    private TeamManager teamManager;
    private ChatManager chatManager;
    private InviteManager inviteManager;
    private TeamInventoryManager teamInventoryManager;
    private SoundManager soundManager;
    private ConfigUtils configUtils;
    private MessageUtils messageUtils;
    private TeamGUI teamGUI;

    private FileConfiguration langConfig;
    private File langFile;

    @Override
    public void onEnable() {
        instance = this;
        getLogger().info("\u001b[32m[BltzTeams] Starting up...\u001b[0m");

        saveDefaultConfig();
        loadLanguage();
        initDatabase();
        initManagers();
        registerCommands();
        registerListeners();
        registerPlaceholders();

        getLogger().info("\u001b[32m[BltzTeams] Enabled successfully!\u001b[0m");
    }

    @Override
    public void onDisable() {
        if (teamInventoryManager != null) {
            // Save any open echests if needed
        }
        if (databaseProvider != null) {
            databaseProvider.close();
        }
        getLogger().info("[BltzTeams] Disabled.");
    }

    private void loadLanguage() {
        String lang = getConfig().getString("language", "en");
        String fileName = "messages_" + lang + ".yml";
        langFile = new File(getDataFolder() + "/messages", fileName);

        if (!langFile.exists()) {
            langFile.getParentFile().mkdirs();
            saveResource("messages/" + fileName, false);
        }

        langConfig = YamlConfiguration.loadConfiguration(langFile);

        // Merge defaults from jar
        InputStream is = getResource("messages/" + fileName);
        if (is != null) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(is, StandardCharsets.UTF_8));
            langConfig.setDefaults(defaults);
        }
    }

    private void initDatabase() {
        String dbType = getConfig().getString("database.type", "h2").toLowerCase();
        if (dbType.equals("h2")) {
            String filename = getConfig().getString("database.filename", "bltzteams_data");
            databaseProvider = new H2DatabaseProvider(this, filename);
        } else {
            databaseProvider = new YamlDatabaseProvider(this);
        }
        databaseProvider.init();
    }

    private void initManagers() {
        configUtils = new ConfigUtils(this);
        messageUtils = new MessageUtils(this);
        chatManager = new ChatManager();
        inviteManager = new InviteManager();
        soundManager = new SoundManager(this);
        teamManager = new TeamManager(this, databaseProvider);
        teamInventoryManager = new TeamInventoryManager(this, databaseProvider);
        teamGUI = new TeamGUI(this);
    }

    private void registerCommands() {
        TeamCommand teamCmd = new TeamCommand(this);
        getCommand("team").setExecutor(teamCmd);
        getCommand("team").setTabCompleter(teamCmd);

        TeamAdminCommand adminCmd = new TeamAdminCommand(this);
        getCommand("teamad").setExecutor(adminCmd);
        getCommand("teamad").setTabCompleter(adminCmd);
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new TeamListener(this), this);
        getServer().getPluginManager().registerEvents(new TeamCrystalListener(this), this);
        getServer().getPluginManager().registerEvents(new TeamEchestListener(this), this);
    }

    private void registerPlaceholders() {
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new TeamPlaceholders(this).register();
            getLogger().info("[BltzTeams] PlaceholderAPI hooked successfully.");
        } else {
            getLogger().info("[BltzTeams] PlaceholderAPI not found, placeholders disabled.");
        }
    }

    public void reloadPlugin() {
        reloadConfig();
        loadLanguage();
        teamManager.loadAll();
    }

    public static BltzTeams getInstance() { return instance; }

    public DatabaseProvider getDatabaseProvider() { return databaseProvider; }
    public TeamManager getTeamManager() { return teamManager; }
    public ChatManager getChatManager() { return chatManager; }
    public InviteManager getInviteManager() { return inviteManager; }
    public TeamInventoryManager getTeamInventoryManager() { return teamInventoryManager; }
    public SoundManager getSoundManager() { return soundManager; }
    public ConfigUtils getConfigUtils() { return configUtils; }
    public MessageUtils getMessageUtils() { return messageUtils; }
    public TeamGUI getTeamGUI() { return teamGUI; }
    public FileConfiguration getLangConfig() { return langConfig; }
}
