package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class LeaveCommand extends SubCommand {

    public LeaveCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "leave"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (team.isOwner(player.getUniqueId())) {
            msg.send(player, msg.getRaw("owner-cannot-leave"));
            plugin.getSoundManager().playError(player);
            return;
        }

        String teamName = team.getName();
        plugin.getChatManager().disableTeamChat(player.getUniqueId());
        tm.removeMember(team, player.getUniqueId());

        msg.sendMsg(player, "team-left", "%team%", teamName);
        plugin.getSoundManager().playTeamLeave(player);

        // Notify remaining members
        for (Player member : Bukkit.getOnlinePlayers()) {
            if (team.hasMember(member.getUniqueId())) {
                msg.send(member, msg.getRaw("player-left-team", "%player%", player.getName()));
            }
        }
    }
}
