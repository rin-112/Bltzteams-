package com.bltz.bltzTeams.commands;

import com.bltz.bltzTeams.BltzTeams;
import org.bukkit.entity.Player;

import java.util.List;

public abstract class AdminSubCommand {

    protected final BltzTeams plugin;

    public AdminSubCommand(BltzTeams plugin) {
        this.plugin = plugin;
    }

    public abstract String getName();

    public abstract void execute(Player player, String[] args);

    public List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }
}
