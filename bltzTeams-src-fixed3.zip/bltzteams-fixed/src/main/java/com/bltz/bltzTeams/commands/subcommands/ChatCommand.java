package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.ChatManager;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class ChatCommand extends SubCommand {

    public ChatCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "chat"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();
        ChatManager cm = plugin.getChatManager();

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_CHAT)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        // If message provided, send directly
        if (args.length > 0) {
            String message = String.join(" ", args);
            sendTeamChat(plugin, player, team, message);
            return;
        }

        // Toggle team chat mode
        if (cm.isInTeamChat(player.getUniqueId())) {
            cm.disableTeamChat(player.getUniqueId());
            msg.sendMsg(player, "team-chat-disabled");
        } else {
            cm.enableTeamChat(player.getUniqueId());
            msg.sendMsg(player, "team-chat-enabled");
        }
    }

    public static void sendTeamChat(BltzTeams plugin, Player player, Team team, String message) {
        String format = plugin.getMessageUtils().getRaw("team-chat-format",
                "%player%", player.getName(), "%message%", message);

        for (Player member : Bukkit.getOnlinePlayers()) {
            if (team.hasMember(member.getUniqueId())) {
                member.sendMessage(format);
            }
        }

        // Chat spy
        String spyFormat = plugin.getMessageUtils().getRaw("admin-team-chat-spy",
                "%team%", team.getName(), "%message%", player.getName() + ": " + message);
        for (Player admin : Bukkit.getOnlinePlayers()) {
            if (plugin.getChatManager().isChatSpy(admin.getUniqueId()) && !team.hasMember(admin.getUniqueId())) {
                admin.sendMessage(spyFormat);
            }
        }
    }
}
