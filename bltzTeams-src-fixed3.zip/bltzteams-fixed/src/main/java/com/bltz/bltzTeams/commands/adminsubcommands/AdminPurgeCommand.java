package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;
import java.util.List;
public class AdminPurgeCommand extends AdminSubCommand {
    public AdminPurgeCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "purge"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length == 0 || !args[0].equalsIgnoreCase("confirm")) {
            msg.sendMsg(player, "admin-purge-confirm");
            return;
        }
        List<Team> allTeams = List.copyOf(plugin.getTeamManager().getAllTeams());
        for (Team team : allTeams) {
            plugin.getTeamManager().disbandTeam(team);
        }
        msg.sendMsg(player, "admin-purge-success");
    }
}
