package com.bltz.bltzTeams.database;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.logging.Logger;

public class H2DatabaseProvider implements DatabaseProvider {

    private final BltzTeams plugin;
    private Connection connection;
    private final String dbFileName;
    private final Logger logger;

    public H2DatabaseProvider(BltzTeams plugin, String dbFileName) {
        this.plugin = plugin;
        this.dbFileName = dbFileName;
        this.logger = plugin.getLogger();
    }

    @Override
    public void init() {
        try {
            Class.forName("org.h2.Driver");
            String url = "jdbc:h2:" + plugin.getDataFolder().getAbsolutePath() + "/" + dbFileName + ";MODE=MySQL;AUTO_SERVER=FALSE";
            connection = DriverManager.getConnection(url, "sa", "");
            createTables();
        } catch (Exception e) {
            logger.severe("Failed to initialize H2 database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void createTables() throws SQLException {
        String teams = "CREATE TABLE IF NOT EXISTS teams (" +
                "team_id VARCHAR(36) PRIMARY KEY," +
                "name VARCHAR(64) NOT NULL UNIQUE," +
                "display_name VARCHAR(128)," +
                "owner_id VARCHAR(36) NOT NULL," +
                "pvp_enabled BOOLEAN DEFAULT FALSE," +
                "created_at BIGINT NOT NULL," +
                "home_world VARCHAR(64)," +
                "home_x DOUBLE," +
                "home_y DOUBLE," +
                "home_z DOUBLE," +
                "home_yaw FLOAT," +
                "home_pitch FLOAT" +
                ")";
        String members = "CREATE TABLE IF NOT EXISTS team_members (" +
                "team_id VARCHAR(36)," +
                "player_id VARCHAR(36)," +
                "joined_at BIGINT," +
                "permissions VARCHAR(64) DEFAULT '1110000000'," +
                "PRIMARY KEY (team_id, player_id)" +
                ")";
        String allies = "CREATE TABLE IF NOT EXISTS team_allies (" +
                "team_id VARCHAR(36)," +
                "ally_team_id VARCHAR(36)," +
                "pvp_enabled BOOLEAN DEFAULT FALSE," +
                "PRIMARY KEY (team_id, ally_team_id)" +
                ")";
        String allyRequests = "CREATE TABLE IF NOT EXISTS ally_requests (" +
                "from_team_id VARCHAR(36)," +
                "to_team_id VARCHAR(36)," +
                "PRIMARY KEY (from_team_id, to_team_id)" +
                ")";
        String echest = "CREATE TABLE IF NOT EXISTS team_echest (" +
                "team_id VARCHAR(36) PRIMARY KEY," +
                "items TEXT" +
                ")";
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(teams);
            stmt.execute(members);
            stmt.execute(allies);
            stmt.execute(allyRequests);
            stmt.execute(echest);
        }
    }

    @Override
    public void save() {
        // H2 auto-saves
    }

    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Team> loadAllTeams() {
        List<Team> teams = new ArrayList<>();
        try {
            // Load all teams basic info
            String sql = "SELECT * FROM teams";
            try (PreparedStatement ps = connection.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    UUID teamId = UUID.fromString(rs.getString("team_id"));
                    String name = rs.getString("name");
                    String displayName = rs.getString("display_name");
                    UUID ownerId = UUID.fromString(rs.getString("owner_id"));
                    boolean pvp = rs.getBoolean("pvp_enabled");
                    long createdAt = rs.getLong("created_at");

                    Location home = null;
                    String worldName = rs.getString("home_world");
                    if (worldName != null) {
                        World world = Bukkit.getWorld(worldName);
                        if (world != null) {
                            home = new Location(world,
                                    rs.getDouble("home_x"),
                                    rs.getDouble("home_y"),
                                    rs.getDouble("home_z"),
                                    rs.getFloat("home_yaw"),
                                    rs.getFloat("home_pitch"));
                        }
                    }

                    // Load members
                    List<UUID> members = new ArrayList<>();
                    Map<UUID, boolean[]> memberPerms = new HashMap<>();
                    try (PreparedStatement ps2 = connection.prepareStatement(
                            "SELECT player_id, permissions FROM team_members WHERE team_id = ?")) {
                        ps2.setString(1, teamId.toString());
                        try (ResultSet rs2 = ps2.executeQuery()) {
                            while (rs2.next()) {
                                UUID memberId = UUID.fromString(rs2.getString("player_id"));
                                members.add(memberId);
                                String permStr = rs2.getString("permissions");
                                boolean[] perms = new boolean[Team.PERM_COUNT];
                                for (int i = 0; i < Math.min(permStr.length(), Team.PERM_COUNT); i++) {
                                    perms[i] = permStr.charAt(i) == '1';
                                }
                                memberPerms.put(memberId, perms);
                            }
                        }
                    }

                    // Load allies
                    Map<UUID, Boolean> alliesMap = new HashMap<>();
                    try (PreparedStatement ps3 = connection.prepareStatement(
                            "SELECT ally_team_id, pvp_enabled FROM team_allies WHERE team_id = ?")) {
                        ps3.setString(1, teamId.toString());
                        try (ResultSet rs3 = ps3.executeQuery()) {
                            while (rs3.next()) {
                                alliesMap.put(UUID.fromString(rs3.getString("ally_team_id")),
                                        rs3.getBoolean("pvp_enabled"));
                            }
                        }
                    }

                    // Load pending requests
                    Set<UUID> pendingReqs = new HashSet<>();
                    try (PreparedStatement ps4 = connection.prepareStatement(
                            "SELECT to_team_id FROM ally_requests WHERE from_team_id = ?")) {
                        ps4.setString(1, teamId.toString());
                        try (ResultSet rs4 = ps4.executeQuery()) {
                            while (rs4.next()) {
                                pendingReqs.add(UUID.fromString(rs4.getString("to_team_id")));
                            }
                        }
                    }

                    Team team = new Team(teamId, name, displayName != null ? displayName : name,
                            ownerId, members, home, pvp, createdAt, memberPerms, alliesMap, pendingReqs);
                    teams.add(team);
                }
            }
        } catch (SQLException e) {
            logger.severe("Failed to load teams: " + e.getMessage());
            e.printStackTrace();
        }
        return teams;
    }

    @Override
    public void saveTeam(Team team) {
        try {
            // Upsert team
            String upsert = "MERGE INTO teams (team_id, name, display_name, owner_id, pvp_enabled, created_at, home_world, home_x, home_y, home_z, home_yaw, home_pitch) " +
                    "KEY(team_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
            try (PreparedStatement ps = connection.prepareStatement(upsert)) {
                ps.setString(1, team.getTeamId().toString());
                ps.setString(2, team.getName());
                ps.setString(3, team.getDisplayName());
                ps.setString(4, team.getOwnerId().toString());
                ps.setBoolean(5, team.isPvpEnabled());
                ps.setLong(6, team.getCreatedAt());
                Location home = team.getHome();
                if (home != null && home.getWorld() != null) {
                    ps.setString(7, home.getWorld().getName());
                    ps.setDouble(8, home.getX());
                    ps.setDouble(9, home.getY());
                    ps.setDouble(10, home.getZ());
                    ps.setFloat(11, home.getYaw());
                    ps.setFloat(12, home.getPitch());
                } else {
                    ps.setNull(7, Types.VARCHAR);
                    ps.setNull(8, Types.DOUBLE);
                    ps.setNull(9, Types.DOUBLE);
                    ps.setNull(10, Types.DOUBLE);
                    ps.setNull(11, Types.FLOAT);
                    ps.setNull(12, Types.FLOAT);
                }
                ps.executeUpdate();
            }

            // Delete and re-insert members
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM team_members WHERE team_id = ?")) {
                ps.setString(1, team.getTeamId().toString());
                ps.executeUpdate();
            }
            for (UUID memberId : team.getMembers()) {
                boolean[] perms = team.getMemberPermissions().getOrDefault(memberId, new boolean[Team.PERM_COUNT]);
                StringBuilder permStr = new StringBuilder();
                for (boolean p : perms) permStr.append(p ? '1' : '0');
                try (PreparedStatement ps = connection.prepareStatement(
                        "INSERT INTO team_members (team_id, player_id, joined_at, permissions) VALUES (?,?,?,?)")) {
                    ps.setString(1, team.getTeamId().toString());
                    ps.setString(2, memberId.toString());
                    ps.setLong(3, System.currentTimeMillis());
                    ps.setString(4, permStr.toString());
                    ps.executeUpdate();
                }
            }

            // Save allies
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM team_allies WHERE team_id = ?")) {
                ps.setString(1, team.getTeamId().toString());
                ps.executeUpdate();
            }
            for (Map.Entry<UUID, Boolean> entry : team.getAllies().entrySet()) {
                try (PreparedStatement ps = connection.prepareStatement(
                        "INSERT INTO team_allies (team_id, ally_team_id, pvp_enabled) VALUES (?,?,?)")) {
                    ps.setString(1, team.getTeamId().toString());
                    ps.setString(2, entry.getKey().toString());
                    ps.setBoolean(3, entry.getValue());
                    ps.executeUpdate();
                }
            }

        } catch (SQLException e) {
            logger.severe("Failed to save team: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void deleteTeam(UUID teamId) {
        try {
            String tid = teamId.toString();
            for (String sql : new String[]{
                    "DELETE FROM teams WHERE team_id = ?",
                    "DELETE FROM team_members WHERE team_id = ?",
                    "DELETE FROM team_allies WHERE team_id = ? OR ally_team_id = ?",
                    "DELETE FROM ally_requests WHERE from_team_id = ? OR to_team_id = ?",
                    "DELETE FROM team_echest WHERE team_id = ?"}) {
                try (PreparedStatement ps = connection.prepareStatement(sql)) {
                    ps.setString(1, tid);
                    if (sql.contains("OR")) {
                        ps.setString(2, tid);
                    }
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ItemStack[] getTeamEchestItems(UUID teamId) {
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT items FROM team_echest WHERE team_id = ?")) {
                ps.setString(1, teamId.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String encoded = rs.getString("items");
                        if (encoded != null && !encoded.isEmpty()) {
                            return deserializeItems(encoded);
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.warning("Error getting echest items: " + e.getMessage());
        }
        return new ItemStack[27];
    }

    @Override
    public void setTeamEchestItems(UUID teamId, ItemStack[] items) {
        try {
            String encoded = serializeItems(items);
            try (PreparedStatement ps = connection.prepareStatement(
                    "MERGE INTO team_echest (team_id, items) KEY(team_id) VALUES (?,?)")) {
                ps.setString(1, teamId.toString());
                ps.setString(2, encoded);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            logger.warning("Error setting echest items: " + e.getMessage());
        }
    }

    private String serializeItems(ItemStack[] items) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream oos = new BukkitObjectOutputStream(baos)) {
            oos.writeInt(items.length);
            for (ItemStack item : items) {
                oos.writeObject(item);
            }
        }
        return Base64.getEncoder().encodeToString(baos.toByteArray());
    }

    private ItemStack[] deserializeItems(String encoded) throws IOException, ClassNotFoundException {
        byte[] bytes = Base64.getDecoder().decode(encoded);
        try (BukkitObjectInputStream ois = new BukkitObjectInputStream(new ByteArrayInputStream(bytes))) {
            int size = ois.readInt();
            ItemStack[] items = new ItemStack[size];
            for (int i = 0; i < size; i++) {
                items[i] = (ItemStack) ois.readObject();
            }
            return items;
        }
    }

    @Override
    public Team getTeamByName(String name) {
        return loadAllTeams().stream()
                .filter(t -> t.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

    @Override
    public Team getTeamByPlayer(UUID playerId) {
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT team_id FROM team_members WHERE player_id = ?")) {
                ps.setString(1, playerId.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        UUID teamId = UUID.fromString(rs.getString("team_id"));
                        return getTeamById(teamId);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Team getTeamById(UUID teamId) {
        return loadAllTeams().stream()
                .filter(t -> t.getTeamId().equals(teamId))
                .findFirst().orElse(null);
    }

    @Override
    public boolean hasAllyRequest(UUID fromTeamId, UUID toTeamId) {
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "SELECT 1 FROM ally_requests WHERE from_team_id = ? AND to_team_id = ?")) {
                ps.setString(1, fromTeamId.toString());
                ps.setString(2, toTeamId.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void addAllyRequest(UUID fromTeamId, UUID toTeamId) {
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "INSERT IGNORE INTO ally_requests (from_team_id, to_team_id) VALUES (?,?)")) {
                ps.setString(1, fromTeamId.toString());
                ps.setString(2, toTeamId.toString());
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void removeAllyRequest(UUID fromTeamId, UUID toTeamId) {
        try {
            try (PreparedStatement ps = connection.prepareStatement(
                    "DELETE FROM ally_requests WHERE from_team_id = ? AND to_team_id = ?")) {
                ps.setString(1, fromTeamId.toString());
                ps.setString(2, toTeamId.toString());
                ps.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
