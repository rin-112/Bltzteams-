package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.UUID;

public class PlayerEditorGUI {

    private final BltzTeams plugin;
    private final Player editor;
    private final Team team;
    private final UUID targetId;

    public PlayerEditorGUI(BltzTeams plugin, Player editor, Team team, UUID targetId) {
        this.plugin = plugin;
        this.editor = editor;
        this.team = team;
        this.targetId = targetId;
    }

    public void open() {
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetId);
        String targetName = target.getName() != null ? target.getName() : "Unknown";
        String title = MessageUtils.colorize(
                plugin.getConfig().getString("gui.team-editor-gui.title", "Edit %player%")
                        .replace("%player%", targetName));

        Inventory inv = Bukkit.createInventory(new EditorGUIHolder(team.getTeamId(), targetId), 27, title);

        boolean[] perms = team.getPerms(targetId);

        String enabled = MessageUtils.colorize(plugin.getConfig().getString("gui.team-editor-gui.items.echest.status.enabled", "&a&lON"));
        String disabled = MessageUtils.colorize(plugin.getConfig().getString("gui.team-editor-gui.items.echest.status.disabled", "&c&lOFF"));

        // Permission items
        addPermItem(inv, 4, "echest", Material.ENDER_CHEST, perms[Team.PERM_ECHEST], targetName, enabled, disabled);
        addPermItem(inv, 10, "homes", Material.WHITE_BANNER, perms[Team.PERM_HOMES], targetName, enabled, disabled);
        addPermItem(inv, 11, "invite", Material.WRITABLE_BOOK, perms[Team.PERM_INVITE], targetName, enabled, disabled);
        addPermItem(inv, 12, "pvp", Material.IRON_SWORD, perms[Team.PERM_PVP], targetName, enabled, disabled);
        addPermItem(inv, 13, "teleport", Material.ENDER_PEARL, perms[Team.PERM_TELEPORT], targetName, enabled, disabled);
        addPermItem(inv, 14, "chat", Material.PAPER, perms[Team.PERM_CHAT], targetName, enabled, disabled);
        addPermItem(inv, 15, "rename", Material.NAME_TAG, perms[Team.PERM_RENAME], targetName, enabled, disabled);
        addPermItem(inv, 16, "setdisplayname", Material.TORCHFLOWER, perms[Team.PERM_SETDISPLAYNAME], targetName, enabled, disabled);
        addPermItem(inv, 21, "manageally", Material.DIAMOND_SWORD, perms[Team.PERM_MANAGEALLY], targetName, enabled, disabled);
        addPermItem(inv, 23, "managemembers", Material.GOLDEN_AXE, perms[Team.PERM_MANAGEMEMBERS], targetName, enabled, disabled);

        // Kick button
        int kickSlot = plugin.getConfig().getInt("gui.team-editor-gui.items.kick.slot", 26);
        inv.setItem(kickSlot, new GUIItemBuilder(Material.OAK_DOOR)
                .name(plugin.getConfig().getString("gui.team-editor-gui.items.kick.name", "&aKick")
                        .replace("%player%", targetName))
                .lore(plugin.getConfig().getStringList("gui.team-editor-gui.items.kick.lore")
                        .stream().map(l -> l.replace("%player%", targetName)).toList())
                .build());

        // Back button
        int backSlot = plugin.getConfig().getInt("gui.team-editor-gui.items.back.slot", 18);
        inv.setItem(backSlot, new GUIItemBuilder(Material.RED_STAINED_GLASS_PANE)
                .name(plugin.getConfig().getString("gui.team-editor-gui.items.back.name", "&cGo Back"))
                .lore(plugin.getConfig().getStringList("gui.team-editor-gui.items.back.lore")).build());

        editor.openInventory(inv);
    }

    private void addPermItem(Inventory inv, int slot, String key, Material defaultMat, boolean permValue, String targetName, String enabled, String disabled) {
        String cfgPath = "gui.team-editor-gui.items." + key;
        Material mat = getMat(cfgPath + ".material", defaultMat);
        String name = MessageUtils.colorize(plugin.getConfig().getString(cfgPath + ".name", "&a" + key))
                .replace("%player%", targetName);
        String status = permValue ? enabled : disabled;
        java.util.List<String> lore = plugin.getConfig().getStringList(cfgPath + ".lore")
                .stream().map(l -> MessageUtils.colorize(l.replace("%player%", targetName).replace("%status%", status)))
                .toList();
        inv.setItem(slot, new GUIItemBuilder(mat).name(name).lore(lore).build());
    }

    private Material getMat(String path, Material def) {
        String name = plugin.getConfig().getString(path);
        if (name == null) return def;
        try { return Material.valueOf(name.toUpperCase()); } catch (Exception e) { return def; }
    }

    public UUID getTargetId() { return targetId; }
    public Team getTeam() { return team; }
}
