package com.bltz.bltzTeams.utils;

import com.bltz.bltzTeams.BltzTeams;
import org.bukkit.entity.Player;

public class MessageUtils {

    public enum DisplayType {
        CHAT, ACTIONBAR, TITLE, BOTH
    }

    private final BltzTeams plugin;

    public MessageUtils(BltzTeams plugin) {
        this.plugin = plugin;
    }

    public void send(Player player, String message) {
        player.sendMessage(colorize(message));
    }

    public void sendMsg(Player player, String msgKey) {
        String displayTypeStr = plugin.getConfig().getString("message-display." + msgKey, "CHAT");
        DisplayType displayType;
        try {
            displayType = DisplayType.valueOf(displayTypeStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            displayType = DisplayType.CHAT;
        }
        String message = plugin.getLangConfig().getString(msgKey, "&cMessage not found: " + msgKey);
        sendWithType(player, displayType, message);
    }

    public void sendMsg(Player player, String msgKey, String... replacements) {
        String displayTypeStr = plugin.getConfig().getString("message-display." + msgKey, "CHAT");
        DisplayType displayType;
        try {
            displayType = DisplayType.valueOf(displayTypeStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            displayType = DisplayType.CHAT;
        }
        String message = plugin.getLangConfig().getString(msgKey, "&cMessage not found: " + msgKey);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        sendWithType(player, displayType, message);
    }

    public String getRaw(String key, String... replacements) {
        String message = plugin.getLangConfig().getString(key, "");
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            message = message.replace(replacements[i], replacements[i + 1]);
        }
        return colorize(message);
    }

    private void sendWithType(Player player, DisplayType type, String message) {
        message = colorize(message);
        switch (type) {
            case TITLE -> player.sendTitle(message, "", 10, 40, 10);
            case ACTIONBAR -> player.sendActionBar(message);
            case BOTH -> {
                player.sendActionBar(message);
                player.sendMessage(message);
            }
            default -> player.sendMessage(message);
        }
    }

    public static String colorize(String text) {
        if (text == null) return "";
        // Handle hex colors &#RRGGBB
        StringBuilder result = new StringBuilder();
        char[] chars = text.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '&' && i + 1 < chars.length) {
                if (chars[i + 1] == '#' && i + 7 < chars.length) {
                    try {
                        String hex = new String(chars, i + 2, 6);
                        Integer.parseInt(hex, 16); // validate
                        result.append('\u00A7').append('x');
                        for (char c : hex.toCharArray()) {
                            result.append('\u00A7').append(c);
                        }
                        i += 7;
                        continue;
                    } catch (NumberFormatException ignored) {}
                } else {
                    char code = chars[i + 1];
                    if ("0123456789AaBbCcDdEeFfKkLlMmNnOoRr".indexOf(code) >= 0) {
                        result.append('\u00A7').append(Character.toLowerCase(code));
                        i++;
                        continue;
                    }
                }
            }
            result.append(chars[i]);
        }
        return result.toString();
    }
}
