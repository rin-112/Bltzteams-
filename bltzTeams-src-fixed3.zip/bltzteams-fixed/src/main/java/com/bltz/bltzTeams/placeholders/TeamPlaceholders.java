package com.bltz.bltzTeams.placeholders;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;


public class TeamPlaceholders extends PlaceholderExpansion {

    private final BltzTeams plugin;

    public TeamPlaceholders(BltzTeams plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() { return "bltzteams"; }

    @Override
    public String getAuthor() { return "bltz"; }

    @Override
    public String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        Team team = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
        String noTeam = MessageUtils.colorize(plugin.getConfig().getString("team.placeholder-no-team", "&7No Team"));

        return switch (params.toLowerCase()) {
            case "team" -> team != null ? team.getName() : noTeam;
            case "team_display" -> team != null ? MessageUtils.colorize(team.getDisplayName()) : noTeam;
            case "team_owner" -> team != null ? team.getOwnerName() : noTeam;
            case "team_members" -> team != null ? String.valueOf(team.getMemberCount()) : "0";
            case "team_pvp" -> team != null ? (team.isPvpEnabled() ? "ON" : "OFF") : "OFF";
            case "team_allies" -> team != null ? String.valueOf(team.getAllies().size()) : "0";
            case "in_team" -> team != null ? "true" : "false";
            case "team_role" -> {
                if (team == null) yield noTeam;
                yield team.isOwner(player.getUniqueId()) ?
                        MessageUtils.colorize(plugin.getConfig().getString("gui.team-gui.defaults.role-owner", "&cOwner")) :
                        MessageUtils.colorize(plugin.getConfig().getString("gui.team-gui.defaults.role-member", "&7Member"));
            }
            default -> null;
        };
    }
}
