package com.bltz.bltzTeams.commands;

import com.bltz.bltzTeams.BltzTeams;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;

public abstract class SubCommand {

    protected final BltzTeams plugin;

    public SubCommand(BltzTeams plugin) {
        this.plugin = plugin;
    }

    public abstract String getName();

    public abstract void execute(Player player, String[] args);

    public List<String> tabComplete(Player player, String[] args) {
        return List.of();
    }
}
