package com.bltz.bltzTeams.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class EditorGUIHolder implements InventoryHolder {
    private final UUID teamId;
    private final UUID targetPlayerId;

    public EditorGUIHolder(UUID teamId, UUID targetPlayerId) {
        this.teamId = teamId;
        this.targetPlayerId = targetPlayerId;
    }

    public UUID getTeamId() { return teamId; }
    public UUID getTargetPlayerId() { return targetPlayerId; }

    @Override public Inventory getInventory() { return null; }
}
