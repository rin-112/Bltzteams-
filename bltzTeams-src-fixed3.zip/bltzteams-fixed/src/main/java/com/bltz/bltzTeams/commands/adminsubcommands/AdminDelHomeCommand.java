package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;
public class AdminDelHomeCommand extends AdminSubCommand {
    public AdminDelHomeCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "delhome"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-delhome")); return; }
        Team team = plugin.getTeamManager().getTeamByName(args[0]);
        if (team == null) { msg.send(player, msg.getRaw("team-not-found", "%team%", args[0])); return; }
        team.setHome(null);
        plugin.getTeamManager().saveTeam(team);
        msg.sendMsg(player, "admin-delhome-success", "%team%", args[0]);
    }
}
