package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
public class AdminLeaveCommand extends AdminSubCommand {
    public AdminLeaveCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "leave"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-leave")); return; }
        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) { msg.send(player, msg.getRaw("player-not-exist")); return; }
        Team team = plugin.getTeamManager().getTeamByPlayer(target.getUniqueId());
        if (team == null) { msg.send(player, msg.getRaw("not-in-team")); return; }
        if (team.isOwner(target.getUniqueId())) {
            // Admin can force-leave owner by disbanding
            plugin.getTeamManager().disbandTeam(team);
        } else {
            plugin.getTeamManager().removeMember(team, target.getUniqueId());
        }
        msg.send(player, msg.getRaw("admin-leave-success", "%player%", args[0]));
    }
}
