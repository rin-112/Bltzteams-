package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TeamAllyGUI {

    private final BltzTeams plugin;
    private final Player player;
    private final int page;

    public TeamAllyGUI(BltzTeams plugin, Player player, int page) {
        this.plugin = plugin;
        this.player = player;
        this.page = page;
    }

    public void open() {
        int guiSize = plugin.getConfig().getInt("gui.ally-gui.gui-size", 45);
        String title = MessageUtils.colorize(
                plugin.getConfig().getString("gui.ally-gui.title", "&8Team List - Page %page%")
                        .replace("%page%", String.valueOf(page + 1)));

        Inventory inv = Bukkit.createInventory(new AllyGUIHolder(), guiSize, title);

        // Fill
        for (int i = 0; i < guiSize; i++) {
            inv.setItem(i, GUIItemBuilder.fillItem(Material.BLACK_STAINED_GLASS_PANE));
        }

        Team myTeam = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());

        // List all teams (excluding my team) for ally selection
        List<Team> allTeams = new ArrayList<>(plugin.getTeamManager().getAllTeams());
        allTeams.removeIf(t -> myTeam != null && t.getTeamId().equals(myTeam.getTeamId()));

        int maxPerPage = plugin.getConfig().getInt("gui.ally-gui.max-teams-per-page", 27);
        int start = page * maxPerPage;
        int end = Math.min(start + maxPerPage, allTeams.size());

        for (int i = start; i < end; i++) {
            Team t = allTeams.get(i);
            String status;
            String statusLine = "";
            if (myTeam != null) {
                if (myTeam.isAlly(t.getTeamId())) {
                    status = plugin.getConfig().getString("gui.ally-gui.items.team-status.ally", "&aAlready allied");
                } else if (plugin.getTeamManager().getDb().hasAllyRequest(myTeam.getTeamId(), t.getTeamId())) {
                    status = plugin.getConfig().getString("gui.ally-gui.items.team-status.sent", "&eAlly request sent");
                } else if (plugin.getTeamManager().getDb().hasAllyRequest(t.getTeamId(), myTeam.getTeamId())) {
                    status = plugin.getConfig().getString("gui.ally-gui.items.team-status.received", "&bAlly request received");
                    statusLine = plugin.getConfig().getString("gui.ally-gui.items.team-status.received-accept", "&7Click to accept");
                } else {
                    status = plugin.getConfig().getString("gui.ally-gui.items.team-status.no-relationship", "&7No ally relationship");
                    statusLine = plugin.getConfig().getString("gui.ally-gui.items.team-status.send", "&7Click to send ally request");
                }
            } else {
                status = "&7No team";
            }

            List<String> lore = new ArrayList<>();
            for (String line : plugin.getConfig().getStringList("gui.ally-gui.items.team.lore")) {
                lore.add(line.replace("%owner%", t.getOwnerName())
                        .replace("%members%", String.valueOf(t.getMemberCount()))
                        .replace("%created%", "N/A")
                        .replace("%status%", status));
            }
            if (!statusLine.isEmpty()) lore.add(statusLine);

            inv.setItem(i - start, new GUIItemBuilder(Material.GLOW_ITEM_FRAME)
                    .name(plugin.getConfig().getString("gui.ally-gui.items.team.name", "&e%team%").replace("%team%", t.getName()))
                    .lore(lore).build());
        }

        // My team info at slot 31
        if (myTeam != null) {
            int myTeamSlot = plugin.getConfig().getInt("gui.ally-gui.items.player-team.slot", 31);
            List<String> allyNames = new ArrayList<>();
            for (UUID allyId : myTeam.getAllies().keySet()) {
                Team ally = plugin.getTeamManager().getTeamById(allyId);
                if (ally != null) allyNames.add("&7- &a" + ally.getName());
            }
            String alliesList = allyNames.isEmpty() ? plugin.getMessageUtils().getRaw("notify_ally_list_empty") : String.join("\n", allyNames);
            List<String> myLore = new ArrayList<>();
            for (String line : plugin.getConfig().getStringList("gui.ally-gui.items.player-team.lore")) {
                myLore.add(line.replace("%owner%", myTeam.getOwnerName())
                        .replace("%members%", String.valueOf(myTeam.getMemberCount()))
                        .replace("%allies_count%", String.valueOf(myTeam.getAllies().size()))
                        .replace("%allies_list%", alliesList)
                        .replace("%pending_count%", "0")
                        .replace("%pending_list%", ""));
            }
            inv.setItem(myTeamSlot, new GUIItemBuilder(Material.IRON_HELMET)
                    .name(plugin.getConfig().getString("gui.ally-gui.items.player-team.name", "&e%team% &7(Your Team)")
                            .replace("%team%", myTeam.getName()))
                    .lore(myLore).build());
        }

        // Navigation
        if (page > 0) {
            int prevSlot = plugin.getConfig().getInt("gui.ally-gui.items.navigation.prev.slot", 27);
            inv.setItem(prevSlot, new GUIItemBuilder(Material.ARROW)
                    .name(plugin.getConfig().getString("gui.ally-gui.items.navigation.prev.name", "&aPrevious Page"))
                    .build());
        }
        if (end < allTeams.size()) {
            int nextSlot = plugin.getConfig().getInt("gui.ally-gui.items.navigation.next.slot", 35);
            inv.setItem(nextSlot, new GUIItemBuilder(Material.ARROW)
                    .name(plugin.getConfig().getString("gui.ally-gui.items.navigation.next.name", "&aNext Page"))
                    .build());
        }

        player.openInventory(inv);
    }

    public int getPage() { return page; }
}
