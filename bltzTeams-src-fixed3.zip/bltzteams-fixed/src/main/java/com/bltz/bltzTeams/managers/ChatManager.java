package com.bltz.bltzTeams.managers;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ChatManager {

    private final Set<UUID> teamChatMode = new HashSet<>();
    private final Set<UUID> chatSpyMode = new HashSet<>();

    public boolean isInTeamChat(UUID playerId) {
        return teamChatMode.contains(playerId);
    }

    public void enableTeamChat(UUID playerId) {
        teamChatMode.add(playerId);
    }

    public void disableTeamChat(UUID playerId) {
        teamChatMode.remove(playerId);
    }

    public boolean isChatSpy(UUID playerId) {
        return chatSpyMode.contains(playerId);
    }

    public void toggleChatSpy(UUID playerId) {
        if (chatSpyMode.contains(playerId)) {
            chatSpyMode.remove(playerId);
        } else {
            chatSpyMode.add(playerId);
        }
    }

    public Set<UUID> getChatSpies() {
        return chatSpyMode;
    }
}
