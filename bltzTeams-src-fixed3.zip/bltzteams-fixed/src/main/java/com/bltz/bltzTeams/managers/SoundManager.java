package com.bltz.bltzTeams.managers;

import com.bltz.bltzTeams.BltzTeams;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class SoundManager {

    private final BltzTeams plugin;

    public SoundManager(BltzTeams plugin) {
        this.plugin = plugin;
    }

    private void play(Player player, String configPath) {
        FileConfiguration cfg = plugin.getConfig();
        String path = "sounds." + configPath;
        if (!cfg.getBoolean(path + ".enabled", true)) return;
        String soundName = cfg.getString(path + ".sound", "BLOCK_NOTE_BLOCK_PLING");
        double volume = cfg.getDouble(path + ".volume", 0.5);
        double pitch = cfg.getDouble(path + ".pitch", 1.0);
        try {
            Sound sound = Sound.valueOf(soundName);
            player.playSound(player.getLocation(), sound, (float) volume, (float) pitch);
        } catch (IllegalArgumentException e) {
            // Invalid sound name, skip
        }
    }

    public void playGuiClick(Player player) { play(player, "gui.click"); }
    public void playSuccess(Player player) { play(player, "success"); }
    public void playError(Player player) { play(player, "error"); }
    public void playWarning(Player player) { play(player, "warning"); }
    public void playTeamCreate(Player player) { play(player, "team.create"); }
    public void playTeamJoin(Player player) { play(player, "team.join"); }
    public void playTeamLeave(Player player) { play(player, "team.leave"); }
    public void playTeamInvite(Player player) { play(player, "team.invite"); }
    public void playTeamKick(Player player) { play(player, "team.kick"); }
    public void playTeamDisband(Player player) { play(player, "team.disband"); }
    public void playTeleportCountdown(Player player) { play(player, "teleport.countdown"); }
    public void playTeleportSuccess(Player player) { play(player, "teleport.success"); }
    public void playInventoryPlace(Player player) { play(player, "inventory.place"); }
    public void playInventoryPickup(Player player) { play(player, "inventory.pickup"); }
}
