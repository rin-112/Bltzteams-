package com.bltz.bltzTeams.commands.adminsubcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AdminSetHomeCommand extends AdminSubCommand {
    public AdminSetHomeCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "sethome"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-sethome")); return; }
        Team team = plugin.getTeamManager().getTeamByName(args[0]);
        if (team == null) { msg.send(player, msg.getRaw("team-not-found", "%team%", args[0])); return; }
        team.setHome(player.getLocation());
        plugin.getTeamManager().saveTeam(team);
        msg.sendMsg(player, "admin-sethome-success", "%team%", args[0]);
    }
}
