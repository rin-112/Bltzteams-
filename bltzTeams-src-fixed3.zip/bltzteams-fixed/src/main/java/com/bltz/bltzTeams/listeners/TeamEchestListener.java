package com.bltz.bltzTeams.listeners;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.gui.TeamEchestGUIHolder;
import com.bltz.bltzTeams.models.Team;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

public class TeamEchestListener implements Listener {

    private final BltzTeams plugin;

    public TeamEchestListener(BltzTeams plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof TeamEchestGUIHolder echestHolder)) return;

        // Check if dragging into protected slots (bottom bar)
        int contentSlots = (plugin.getConfig().getInt("gui.team-echest.content.end-col", 8) -
                plugin.getConfig().getInt("gui.team-echest.content.start-col", 0) + 1) *
                plugin.getConfig().getInt("gui.team-echest.content.rows", 3);

        int guiSize = plugin.getConfig().getInt("gui.team-echest.size", 36);

        for (int slot : event.getRawSlots()) {
            if (slot >= contentSlots && slot < guiSize) {
                event.setCancelled(true);
                return;
            }
        }
    }
}
