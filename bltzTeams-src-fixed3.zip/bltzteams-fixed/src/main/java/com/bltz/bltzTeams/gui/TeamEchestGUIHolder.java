package com.bltz.bltzTeams.gui;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class TeamEchestGUIHolder implements InventoryHolder {
    private final UUID teamId;
    public TeamEchestGUIHolder(UUID teamId) { this.teamId = teamId; }
    public UUID getTeamId() { return teamId; }
    @Override public Inventory getInventory() { return null; }
}
