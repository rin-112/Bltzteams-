package com.bltz.bltzTeams.database;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.*;
import java.util.*;
import java.util.logging.Logger;

public class YamlDatabaseProvider implements DatabaseProvider {

    private final BltzTeams plugin;
    private final Logger logger;
    private File dataFile;
    private YamlConfiguration data;

    // Ally requests stored separately in memory
    private final Set<String> allyRequests = new HashSet<>();

    public YamlDatabaseProvider(BltzTeams plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }

    @Override
    public void init() {
        dataFile = new File(plugin.getDataFolder(), "teams_data.yml");
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        data = YamlConfiguration.loadConfiguration(dataFile);
        // Load ally requests
        List<String> reqs = data.getStringList("ally_requests");
        allyRequests.addAll(reqs);
    }

    @Override
    public void save() {
        data.set("ally_requests", new ArrayList<>(allyRequests));
        try {
            data.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() {
        save();
    }

    @Override
    public List<Team> loadAllTeams() {
        List<Team> teams = new ArrayList<>();
        ConfigurationSection teamsSection = data.getConfigurationSection("teams");
        if (teamsSection == null) return teams;

        for (String teamIdStr : teamsSection.getKeys(false)) {
            try {
                UUID teamId = UUID.fromString(teamIdStr);
                String path = "teams." + teamIdStr;
                String name = data.getString(path + ".name");
                String displayName = data.getString(path + ".display_name", name);
                UUID ownerId = UUID.fromString(data.getString(path + ".owner"));
                boolean pvp = data.getBoolean(path + ".pvp", false);
                long createdAt = data.getLong(path + ".created_at", System.currentTimeMillis());

                Location home = null;
                if (data.contains(path + ".home.world")) {
                    String worldName = data.getString(path + ".home.world");
                    World world = Bukkit.getWorld(worldName);
                    if (world != null) {
                        home = new Location(world,
                                data.getDouble(path + ".home.x"),
                                data.getDouble(path + ".home.y"),
                                data.getDouble(path + ".home.z"),
                                (float) data.getDouble(path + ".home.yaw"),
                                (float) data.getDouble(path + ".home.pitch"));
                    }
                }

                List<UUID> members = new ArrayList<>();
                Map<UUID, boolean[]> memberPerms = new HashMap<>();
                ConfigurationSection membersSection = data.getConfigurationSection(path + ".members");
                if (membersSection != null) {
                    for (String memberIdStr : membersSection.getKeys(false)) {
                        UUID memberId = UUID.fromString(memberIdStr);
                        members.add(memberId);
                        String permStr = data.getString(path + ".members." + memberIdStr + ".permissions", "");
                        boolean[] perms = new boolean[Team.PERM_COUNT];
                        for (int i = 0; i < Math.min(permStr.length(), Team.PERM_COUNT); i++) {
                            perms[i] = permStr.charAt(i) == '1';
                        }
                        memberPerms.put(memberId, perms);
                    }
                }

                Map<UUID, Boolean> allies = new HashMap<>();
                ConfigurationSection alliesSection = data.getConfigurationSection(path + ".allies");
                if (alliesSection != null) {
                    for (String allyIdStr : alliesSection.getKeys(false)) {
                        allies.put(UUID.fromString(allyIdStr),
                                data.getBoolean(path + ".allies." + allyIdStr + ".pvp", false));
                    }
                }

                Set<UUID> pendingReqs = new HashSet<>();
                for (String req : allyRequests) {
                    String[] parts = req.split(":");
                    if (parts.length == 2 && parts[0].equals(teamIdStr)) {
                        pendingReqs.add(UUID.fromString(parts[1]));
                    }
                }

                teams.add(new Team(teamId, name, displayName, ownerId, members, home, pvp, createdAt, memberPerms, allies, pendingReqs));
            } catch (Exception e) {
                logger.warning("Failed to load team " + teamIdStr + ": " + e.getMessage());
            }
        }
        return teams;
    }

    @Override
    public void saveTeam(Team team) {
        String path = "teams." + team.getTeamId();
        data.set(path + ".name", team.getName());
        data.set(path + ".display_name", team.getDisplayName());
        data.set(path + ".owner", team.getOwnerId().toString());
        data.set(path + ".pvp", team.isPvpEnabled());
        data.set(path + ".created_at", team.getCreatedAt());

        Location home = team.getHome();
        if (home != null && home.getWorld() != null) {
            data.set(path + ".home.world", home.getWorld().getName());
            data.set(path + ".home.x", home.getX());
            data.set(path + ".home.y", home.getY());
            data.set(path + ".home.z", home.getZ());
            data.set(path + ".home.yaw", home.getYaw());
            data.set(path + ".home.pitch", home.getPitch());
        } else {
            data.set(path + ".home", null);
        }

        // Save members
        data.set(path + ".members", null);
        for (UUID memberId : team.getMembers()) {
            boolean[] perms = team.getMemberPermissions().getOrDefault(memberId, new boolean[Team.PERM_COUNT]);
            StringBuilder permStr = new StringBuilder();
            for (boolean p : perms) permStr.append(p ? '1' : '0');
            data.set(path + ".members." + memberId + ".permissions", permStr.toString());
        }

        // Save allies
        data.set(path + ".allies", null);
        for (Map.Entry<UUID, Boolean> entry : team.getAllies().entrySet()) {
            data.set(path + ".allies." + entry.getKey() + ".pvp", entry.getValue());
        }

        save();
    }

    @Override
    public void deleteTeam(UUID teamId) {
        data.set("teams." + teamId, null);
        allyRequests.removeIf(r -> r.startsWith(teamId + ":") || r.endsWith(":" + teamId));
        save();
    }

    @Override
    public ItemStack[] getTeamEchestItems(UUID teamId) {
        String encoded = data.getString("echest." + teamId);
        if (encoded == null || encoded.isEmpty()) return new ItemStack[27];
        try {
            byte[] bytes = Base64.getDecoder().decode(encoded);
            try (BukkitObjectInputStream ois = new BukkitObjectInputStream(new ByteArrayInputStream(bytes))) {
                int size = ois.readInt();
                ItemStack[] items = new ItemStack[size];
                for (int i = 0; i < size; i++) {
                    items[i] = (ItemStack) ois.readObject();
                }
                return items;
            }
        } catch (Exception e) {
            logger.warning("Error loading echest: " + e.getMessage());
            return new ItemStack[27];
        }
    }

    @Override
    public void setTeamEchestItems(UUID teamId, ItemStack[] items) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            try (BukkitObjectOutputStream oos = new BukkitObjectOutputStream(baos)) {
                oos.writeInt(items.length);
                for (ItemStack item : items) oos.writeObject(item);
            }
            data.set("echest." + teamId, Base64.getEncoder().encodeToString(baos.toByteArray()));
            save();
        } catch (Exception e) {
            logger.warning("Error saving echest: " + e.getMessage());
        }
    }

    @Override
    public Team getTeamByName(String name) {
        return loadAllTeams().stream()
                .filter(t -> t.getName().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

    @Override
    public Team getTeamByPlayer(UUID playerId) {
        return loadAllTeams().stream()
                .filter(t -> t.hasMember(playerId))
                .findFirst().orElse(null);
    }

    @Override
    public Team getTeamById(UUID teamId) {
        return loadAllTeams().stream()
                .filter(t -> t.getTeamId().equals(teamId))
                .findFirst().orElse(null);
    }

    @Override
    public boolean hasAllyRequest(UUID fromTeamId, UUID toTeamId) {
        return allyRequests.contains(fromTeamId + ":" + toTeamId);
    }

    @Override
    public void addAllyRequest(UUID fromTeamId, UUID toTeamId) {
        allyRequests.add(fromTeamId + ":" + toTeamId);
        save();
    }

    @Override
    public void removeAllyRequest(UUID fromTeamId, UUID toTeamId) {
        allyRequests.remove(fromTeamId + ":" + toTeamId);
        save();
    }
}
