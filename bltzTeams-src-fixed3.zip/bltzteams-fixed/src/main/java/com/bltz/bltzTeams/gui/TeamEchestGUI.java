package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class TeamEchestGUI {

    private final BltzTeams plugin;
    private final Player player;
    private final Team team;

    public TeamEchestGUI(BltzTeams plugin, Player player, Team team) {
        this.plugin = plugin;
        this.player = player;
        this.team = team;
    }

    public void open() {
        int guiSize = plugin.getConfig().getInt("gui.team-echest.size", 36);
        String title = MessageUtils.colorize(
                plugin.getConfig().getString("gui.team-echest.title", "Team Ender Chest - %team%")
                        .replace("%team%", team.getName()));

        Inventory inv = Bukkit.createInventory(new TeamEchestGUIHolder(team.getTeamId()), guiSize, title);

        // Load stored items
        ItemStack[] stored = plugin.getTeamInventoryManager().getTeamEchest(team);
        int startCol = plugin.getConfig().getInt("gui.team-echest.content.start-col", 0);
        int endCol = plugin.getConfig().getInt("gui.team-echest.content.end-col", 8);
        int rows = plugin.getConfig().getInt("gui.team-echest.content.rows", 3);
        int contentSlots = (endCol - startCol + 1) * rows;

        for (int i = 0; i < Math.min(stored.length, contentSlots); i++) {
            inv.setItem(i, stored[i]);
        }

        // Bottom bar custom items
        int backSlot = plugin.getConfig().getInt("gui.team-echest.custom-items.back.slot", 27);
        int infoSlot = plugin.getConfig().getInt("gui.team-echest.custom-items.info.slot", 31);
        List<Integer> fillSlots = plugin.getConfig().getIntegerList("gui.team-echest.custom-items.fill.slot");

        if (backSlot < guiSize) {
            inv.setItem(backSlot, new GUIItemBuilder(Material.ARROW)
                    .name(plugin.getConfig().getString("gui.team-echest.custom-items.back.name", "&c&l\u2190 Back to Team"))
                    .lore(plugin.getConfig().getStringList("gui.team-echest.custom-items.back.lore")).build());
        }

        if (infoSlot < guiSize) {
            inv.setItem(infoSlot, new GUIItemBuilder(Material.ENDER_CHEST)
                    .name(plugin.getConfig().getString("gui.team-echest.custom-items.info.name", "&eTeam Ender Chest"))
                    .lore(plugin.getConfig().getStringList("gui.team-echest.custom-items.info.lore")).build());
        }

        for (int slot : fillSlots) {
            if (slot < guiSize) {
                inv.setItem(slot, GUIItemBuilder.fillItem(Material.BLACK_STAINED_GLASS_PANE));
            }
        }

        player.openInventory(inv);
    }
}
