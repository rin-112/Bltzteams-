package com.bltz.bltzTeams.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.UUID;

public class TeamGUIHolder implements InventoryHolder {
    @Override public Inventory getInventory() { return null; }
}
