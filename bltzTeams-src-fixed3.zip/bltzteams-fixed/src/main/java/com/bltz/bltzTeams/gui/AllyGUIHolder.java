package com.bltz.bltzTeams.gui;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;


public class AllyGUIHolder implements InventoryHolder {
    @Override public Inventory getInventory() { return null; }
}
