package com.bltz.bltzTeams.utils;

import com.bltz.bltzTeams.BltzTeams;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

public class ConfigUtils {

    private final BltzTeams plugin;

    public ConfigUtils(BltzTeams plugin) {
        this.plugin = plugin;
    }

    public FileConfiguration getConfig() {
        return plugin.getConfig();
    }

    public String getString(String path, String def) {
        return plugin.getConfig().getString(path, def);
    }

    public int getInt(String path, int def) {
        return plugin.getConfig().getInt(path, def);
    }

    public boolean getBoolean(String path, boolean def) {
        return plugin.getConfig().getBoolean(path, def);
    }

    public List<String> getStringList(String path) {
        return plugin.getConfig().getStringList(path);
    }

    public Material getMaterial(String path, Material def) {
        String name = plugin.getConfig().getString(path);
        if (name == null) return def;
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return def;
        }
    }

    public int getMaxMembers() {
        return plugin.getConfig().getInt("team.max-members", 45);
    }

    public int getTeleportDelay() {
        return plugin.getConfig().getInt("team.teleport-delay", 5);
    }

    public int getNameMinLength() {
        return plugin.getConfig().getInt("team.name-min-length", 3);
    }

    public int getNameMaxLength() {
        return plugin.getConfig().getInt("team.name-max-length", 16);
    }

    public int getDisplayNameMinLength() {
        return plugin.getConfig().getInt("team.displayname-min-length", 3);
    }

    public int getDisplayNameMaxLength() {
        return plugin.getConfig().getInt("team.displayname-max-length", 32);
    }

    public boolean isTeamChatEnabled() {
        return plugin.getConfig().getBoolean("team.chat.enabled", true);
    }

    public boolean isAutoTeamChat() {
        return plugin.getConfig().getBoolean("team.chat.auto-team-chat", false);
    }

    public boolean isShowTeamChatInPublic() {
        return plugin.getConfig().getBoolean("team.chat.show-team-chat-in-public", false);
    }

    public boolean isHidePublicChat() {
        return plugin.getConfig().getBoolean("team.chat.hide-public-chat", false);
    }

    public boolean isProtectTeamFromCrystal() {
        return plugin.getConfig().getBoolean("crystal-pvp.team.crystal", true);
    }

    public boolean isProtectTeamFromAnchor() {
        return plugin.getConfig().getBoolean("crystal-pvp.team.anchor", true);
    }

    public boolean isProtectAllyFromCrystal() {
        return plugin.getConfig().getBoolean("crystal-pvp.ally.crystal", true);
    }

    public boolean isProtectAllyFromAnchor() {
        return plugin.getConfig().getBoolean("crystal-pvp.ally.anchor", true);
    }
}
