package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class TeamGUI {

    private final BltzTeams plugin;
    private static final int GUI_SIZE = 54;
    private static final int MEMBERS_PER_PAGE = 45;

    public TeamGUI(BltzTeams plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, int page) {
        Team team = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
        if (team == null) return;

        String titleTemplate = plugin.getConfig().getString("gui.team-gui.title", "Team (Page %page%)");
        String title = MessageUtils.colorize(titleTemplate.replace("%page%", String.valueOf(page + 1)));

        Inventory inv = Bukkit.createInventory(new TeamGUIHolder(), GUI_SIZE, title);

        // Fill with glass panes
        ItemStack fill = GUIItemBuilder.fillItem(getMaterial("gui.team-gui.items.fill.material", Material.GRAY_STAINED_GLASS_PANE));
        for (int i = 45; i < GUI_SIZE; i++) {
            inv.setItem(i, fill);
        }

        // Add member heads (slots 0-44)
        List<UUID> members = sortMembers(team, player.getUniqueId());
        int start = page * MEMBERS_PER_PAGE;
        int end = Math.min(start + MEMBERS_PER_PAGE, members.size());

        for (int i = start; i < end; i++) {
            UUID memberId = members.get(i);
            OfflinePlayer op = Bukkit.getOfflinePlayer(memberId);
            String role = team.isOwner(memberId) ?
                    plugin.getConfig().getString("gui.team-gui.defaults.role-owner", "&cOwner") :
                    plugin.getConfig().getString("gui.team-gui.defaults.role-member", "&7Member");
            String status = Bukkit.getPlayer(memberId) != null ?
                    plugin.getConfig().getString("gui.team-gui.defaults.status-online", "&aOnline") :
                    plugin.getConfig().getString("gui.team-gui.defaults.status-offline", "&cOffline");

            String name = op.getName() != null ? op.getName() : "Unknown";
            List<String> lore = new ArrayList<>();
            List<String> loreCfg = plugin.getConfig().getStringList("gui.team-gui.items.member-head.lore");
            for (String line : loreCfg) {
                lore.add(line.replace("%role%", role).replace("%status%", status)
                        .replace("%player%", name).replace("%join_date%", "N/A"));
            }

            ItemStack head = new GUIItemBuilder(Material.PLAYER_HEAD)
                    .skullOwner(op)
                    .name(plugin.getConfig().getString("gui.team-gui.items.member-head.name", "&f%player%")
                            .replace("%player%", name))
                    .lore(lore)
                    .build();
            inv.setItem(i - start, head);
        }

        // Navigation buttons
        int infoSlot = plugin.getConfig().getInt("gui.team-gui.items.info.slot", 49);
        int homeSlot = plugin.getConfig().getInt("gui.team-gui.items.home.slot", 52);
        int pvpSlot = plugin.getConfig().getInt("gui.team-gui.items.pvp.slot", 53);
        int echestSlot = plugin.getConfig().getInt("gui.team-gui.items.echest.slot", 51);
        int prevSlot = plugin.getConfig().getInt("gui.team-gui.items.previous-page.slot", 48);
        int nextSlot = plugin.getConfig().getInt("gui.team-gui.items.next-page.slot", 50);
        int searchSlot = plugin.getConfig().getInt("gui.team-gui.items.search.slot", 45);
        int filterSlot = plugin.getConfig().getInt("gui.team-gui.items.filter.slot", 46);

        // Info item
        List<String> infoLore = plugin.getConfig().getStringList("gui.team-gui.items.info.lore");
        List<String> processedInfoLore = infoLore.stream()
                .map(l -> l.replace("%owner%", team.getOwnerName()).replace("%members%", String.valueOf(team.getMemberCount())))
                .collect(Collectors.toList());
        inv.setItem(infoSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.info.material", Material.IRON_HELMET))
                .name(plugin.getConfig().getString("gui.team-gui.items.info.name", "&eTeam %team%").replace("%team%", team.getName()))
                .lore(processedInfoLore).build());

        // Home item
        inv.setItem(homeSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.home.material", Material.WHITE_BANNER))
                .name(plugin.getConfig().getString("gui.team-gui.items.home.name", "&eTeam Home"))
                .lore(plugin.getConfig().getStringList("gui.team-gui.items.home.lore")).build());

        // PvP item
        String pvpStatus = team.isPvpEnabled() ? "&a&lON" : "&c&lOFF";
        List<String> pvpLore = plugin.getConfig().getStringList("gui.team-gui.items.pvp.lore")
                .stream().map(l -> l.replace("%pvp_status%", pvpStatus)).collect(Collectors.toList());
        inv.setItem(pvpSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.pvp.material", Material.IRON_SWORD))
                .name(plugin.getConfig().getString("gui.team-gui.items.pvp.name", "&eTeam PvP"))
                .lore(pvpLore).build());

        // Echest
        inv.setItem(echestSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.echest.material", Material.ENDER_CHEST))
                .name(plugin.getConfig().getString("gui.team-gui.items.echest.name", "&eTeam Ender Chest"))
                .lore(plugin.getConfig().getStringList("gui.team-gui.items.echest.lore")).build());

        // Prev page
        if (page > 0) {
            inv.setItem(prevSlot, new GUIItemBuilder(Material.ARROW)
                    .name(plugin.getConfig().getString("gui.team-gui.items.previous-page.name", "&ePrevious Page"))
                    .lore(plugin.getConfig().getStringList("gui.team-gui.items.previous-page.lore")).build());
        }

        // Next page
        if (end < members.size()) {
            inv.setItem(nextSlot, new GUIItemBuilder(Material.ARROW)
                    .name(plugin.getConfig().getString("gui.team-gui.items.next-page.name", "&eNext Page"))
                    .lore(plugin.getConfig().getStringList("gui.team-gui.items.next-page.lore")).build());
        }

        // Search
        inv.setItem(searchSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.search.material", Material.OAK_SIGN))
                .name(plugin.getConfig().getString("gui.team-gui.items.search.name", "&eSearch"))
                .lore(plugin.getConfig().getStringList("gui.team-gui.items.search.lore")).build());

        // Filter
        inv.setItem(filterSlot, new GUIItemBuilder(getMaterial("gui.team-gui.items.filter.material", Material.HOPPER))
                .name(plugin.getConfig().getString("gui.team-gui.items.filter.name", "&eFilter"))
                .build());

        player.openInventory(inv);
    }

    private List<UUID> sortMembers(Team team, UUID viewerId) {
        List<UUID> sorted = new ArrayList<>(team.getMembers());
        sorted.sort((a, b) -> {
            if (team.isOwner(a)) return -1;
            if (team.isOwner(b)) return 1;
            return 0;
        });
        return sorted;
    }

    private Material getMaterial(String path, Material def) {
        String name = plugin.getConfig().getString(path);
        if (name == null) return def;
        try { return Material.valueOf(name.toUpperCase()); } catch (IllegalArgumentException e) { return def; }
    }
}
