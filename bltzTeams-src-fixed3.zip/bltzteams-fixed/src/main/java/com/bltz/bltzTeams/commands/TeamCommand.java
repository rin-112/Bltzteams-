package com.bltz.bltzTeams.commands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.subcommands.*;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;

public class TeamCommand implements CommandExecutor, TabCompleter {

    private final BltzTeams plugin;
    private final Map<String, SubCommand> subCommands = new LinkedHashMap<>();

    public TeamCommand(BltzTeams plugin) {
        this.plugin = plugin;
        register(new CreateCommand(plugin));
        register(new JoinCommand(plugin));
        register(new LeaveCommand(plugin));
        register(new InviteCommand(plugin));
        register(new KickCommand(plugin));
        register(new DisbandCommand(plugin));
        register(new HomeCommand(plugin));
        register(new SethomeCommand(plugin));
        register(new DelhomeCommand(plugin));
        register(new ChatCommand(plugin));
        register(new InfoCommand(plugin));
        register(new RenameCommand(plugin));
        register(new SetDisplayNameCommand(plugin));
        register(new AllyCommand(plugin));
        register(new EchestCommand(plugin));
        register(new AcceptCommand(plugin));
    }

    private void register(SubCommand cmd) {
        subCommands.put(cmd.getName().toLowerCase(), cmd);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageUtils().getRaw("only-player-command"));
            return true;
        }

        if (args.length == 0) {
            // Open team GUI
            var team = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
            if (team != null) {
                plugin.getTeamGUI().open(player, 0);
            } else {
                sendHelp(player);
            }
            return true;
        }

        String subName = args[0].toLowerCase();
        SubCommand sub = subCommands.get(subName);

        if (sub == null) {
            sendHelp(player);
            return true;
        }

        String[] subArgs = Arrays.copyOfRange(args, 1, args.length);
        sub.execute(player, subArgs);
        return true;
    }

    private void sendHelp(Player player) {
        MessageUtils msg = plugin.getMessageUtils();
        List<String> help = plugin.getLangConfig().getStringList("help-commands");
        for (String line : help) {
            player.sendMessage(MessageUtils.colorize(line));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player)) return List.of();

        if (args.length == 1) {
            List<String> completions = new ArrayList<>(subCommands.keySet());
            completions.removeIf(s -> !s.startsWith(args[0].toLowerCase()));
            return completions;
        }

        if (args.length > 1) {
            SubCommand sub = subCommands.get(args[0].toLowerCase());
            if (sub != null) {
                return sub.tabComplete(player, Arrays.copyOfRange(args, 1, args.length));
            }
        }

        return List.of();
    }
}
