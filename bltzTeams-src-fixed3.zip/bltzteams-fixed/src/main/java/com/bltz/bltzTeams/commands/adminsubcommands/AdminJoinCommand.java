package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public class AdminJoinCommand extends AdminSubCommand {
    public AdminJoinCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "join"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-join")); return; }
        if (plugin.getTeamManager().isInTeam(player.getUniqueId())) {
            msg.send(player, msg.getRaw("already-in-team")); return;
        }
        Team team = plugin.getTeamManager().getTeamByName(args[0]);
        if (team == null) { msg.send(player, msg.getRaw("team-not-found", "%team%", args[0])); return; }
        plugin.getTeamManager().addMember(team, player.getUniqueId());
        msg.send(player, msg.getRaw("admin-join-success", "%team%", args[0]));
    }
}
