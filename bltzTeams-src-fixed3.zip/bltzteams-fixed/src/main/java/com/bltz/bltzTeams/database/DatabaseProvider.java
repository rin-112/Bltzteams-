package com.bltz.bltzTeams.database;

import com.bltz.bltzTeams.models.Team;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public interface DatabaseProvider {

    void init();

    void save();

    void close();

    // Team CRUD
    List<Team> loadAllTeams();

    void saveTeam(Team team);

    void deleteTeam(UUID teamId);

    // Team echest
    ItemStack[] getTeamEchestItems(UUID teamId);

    void setTeamEchestItems(UUID teamId, ItemStack[] items);

    // Lookup
    Team getTeamByName(String name);

    Team getTeamByPlayer(UUID playerId);

    Team getTeamById(UUID teamId);

    // Ally requests
    boolean hasAllyRequest(UUID fromTeamId, UUID toTeamId);

    void addAllyRequest(UUID fromTeamId, UUID toTeamId);

    void removeAllyRequest(UUID fromTeamId, UUID toTeamId);
}
