package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;

public class SetDisplayNameCommand extends SubCommand {

    public SetDisplayNameCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "setdisplayname"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-setdisplayname"));
            return;
        }

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_SETDISPLAYNAME)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        String displayName = String.join(" ", args);
        // Strip color codes to measure length
        String stripped = displayName.replaceAll("&[0-9a-fA-FkKlLmMnNoOrR]", "")
                .replaceAll("&#[0-9a-fA-F]{6}", "");

        int min = plugin.getConfigUtils().getDisplayNameMinLength();
        int max = plugin.getConfigUtils().getDisplayNameMaxLength();

        if (stripped.length() < min || stripped.length() > max) {
            msg.send(player, msg.getRaw("displayname-length",
                    "%min%", String.valueOf(min), "%max%", String.valueOf(max)));
            plugin.getSoundManager().playError(player);
            return;
        }

        team.setDisplayName(displayName);
        tm.saveTeam(team);
        msg.sendMsg(player, "displayname-set", "%displayname%", MessageUtils.colorize(displayName));
        plugin.getSoundManager().playSuccess(player);
    }
}
