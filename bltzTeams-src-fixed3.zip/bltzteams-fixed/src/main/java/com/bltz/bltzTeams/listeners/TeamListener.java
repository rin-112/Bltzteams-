package com.bltz.bltzTeams.listeners;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.subcommands.ChatCommand;
import com.bltz.bltzTeams.gui.*;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class TeamListener implements Listener {

    private final BltzTeams plugin;

    public TeamListener(BltzTeams plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        TeamManager tm = plugin.getTeamManager();
        Team team = tm.getTeamByPlayer(player.getUniqueId());

        if (team == null) return;

        boolean inTeamChat = plugin.getChatManager().isInTeamChat(player.getUniqueId());
        boolean autoTeamChat = plugin.getConfigUtils().isAutoTeamChat();

        if (inTeamChat || autoTeamChat) {
            // Verify still has permission
            if (!team.hasPerm(player.getUniqueId(), Team.PERM_CHAT)) {
                plugin.getChatManager().disableTeamChat(player.getUniqueId());
                plugin.getMessageUtils().send(player, plugin.getMessageUtils().getRaw("team-chat-lost-permission"));
                return;
            }

            event.setCancelled(true);
            String message = event.getMessage();

            Bukkit.getScheduler().runTask(plugin, () ->
                    ChatCommand.sendTeamChat(plugin, player, team, message));

            if (plugin.getConfigUtils().isShowTeamChatInPublic()) {
                event.setCancelled(false);
            }
        } else if (plugin.getConfigUtils().isHidePublicChat()) {
            // Hide public chat from team members if configured
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getChatManager().disableTeamChat(event.getPlayer().getUniqueId());
        plugin.getInviteManager().clearInvites(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();

        if (holder instanceof TeamGUIHolder) {
            handleTeamGUIClick(event, player);
        } else if (holder instanceof EditorGUIHolder editorHolder) {
            handleEditorGUIClick(event, player, editorHolder);
        } else if (holder instanceof DisbandGUIHolder) {
            handleDisbandGUIClick(event, player);
        } else if (holder instanceof AllyGUIHolder) {
            handleAllyGUIClick(event, player);
        } else if (holder instanceof InfoGUIHolder) {
            event.setCancelled(true);
        } else if (holder instanceof TeamEchestGUIHolder echestHolder) {
            handleEchestClick(event, player, echestHolder);
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();

        if (holder instanceof TeamEchestGUIHolder echestHolder) {
            // Save echest contents
            Team team = plugin.getTeamManager().getTeamById(echestHolder.getTeamId());
            if (team != null) {
                ItemStack[] contents = event.getInventory().getContents();
                int guiSize = plugin.getConfig().getInt("gui.team-echest.size", 36);
                int rows = plugin.getConfig().getInt("gui.team-echest.content.rows", 3);
                int contentSlots = (plugin.getConfig().getInt("gui.team-echest.content.end-col", 8) -
                        plugin.getConfig().getInt("gui.team-echest.content.start-col", 0) + 1) * rows;
                ItemStack[] items = new ItemStack[contentSlots];
                for (int i = 0; i < Math.min(contentSlots, contents.length); i++) {
                    items[i] = contents[i];
                }
                plugin.getTeamInventoryManager().saveTeamEchest(team, items);
            }
        }
    }

    private void handleTeamGUIClick(InventoryClickEvent event, Player player) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        plugin.getSoundManager().playGuiClick(player);

        Team team = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
        if (team == null) { player.closeInventory(); return; }

        int infoSlot = plugin.getConfig().getInt("gui.team-gui.items.info.slot", 49);
        int homeSlot = plugin.getConfig().getInt("gui.team-gui.items.home.slot", 52);
        int pvpSlot = plugin.getConfig().getInt("gui.team-gui.items.pvp.slot", 53);
        int echestSlot = plugin.getConfig().getInt("gui.team-gui.items.echest.slot", 51);
        int prevSlot = plugin.getConfig().getInt("gui.team-gui.items.previous-page.slot", 48);
        int nextSlot = plugin.getConfig().getInt("gui.team-gui.items.next-page.slot", 50);

        if (slot == infoSlot) {
            // Refresh
            player.closeInventory();
            plugin.getTeamGUI().open(player, 0);
        } else if (slot == homeSlot) {
            player.closeInventory();
            plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
            if (team.getHome() == null) {
                plugin.getMessageUtils().send(player, plugin.getMessageUtils().getRaw("no-home-set"));
            } else {
                new com.bltz.bltzTeams.commands.subcommands.HomeCommand(plugin).execute(player, new String[]{});
            }
        } else if (slot == pvpSlot) {
            if (team.hasPerm(player.getUniqueId(), Team.PERM_PVP)) {
                team.setPvpEnabled(!team.isPvpEnabled());
                plugin.getTeamManager().saveTeam(team);
                String msg = team.isPvpEnabled() ?
                        plugin.getMessageUtils().getRaw("pvp-enabled") :
                        plugin.getMessageUtils().getRaw("pvp-disabled");
                plugin.getMessageUtils().send(player, msg);
                player.closeInventory();
                plugin.getTeamGUI().open(player, 0);
            }
        } else if (slot == echestSlot) {
            player.closeInventory();
            if (team.hasPerm(player.getUniqueId(), Team.PERM_ECHEST)) {
                new TeamEchestGUI(plugin, player, team).open();
            }
        } else if (slot < 45) {
            // Clicked a member head
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            // Find which member was clicked based on slot
            java.util.List<UUID> members = new java.util.ArrayList<>(team.getMembers());
            members.sort((a, b) -> team.isOwner(a) ? -1 : team.isOwner(b) ? 1 : 0);
            if (slot < members.size()) {
                UUID targetId = members.get(slot);
                if (!targetId.equals(player.getUniqueId()) && team.hasPerm(player.getUniqueId(), Team.PERM_MANAGEMEMBERS)) {
                    new PlayerEditorGUI(plugin, player, team, targetId).open();
                }
            }
        }
    }

    private void handleEditorGUIClick(InventoryClickEvent event, Player player, EditorGUIHolder holder) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        plugin.getSoundManager().playGuiClick(player);

        Team team = plugin.getTeamManager().getTeamById(holder.getTeamId());
        UUID targetId = holder.getTargetPlayerId();
        if (team == null) { player.closeInventory(); return; }

        MessageUtils msg = plugin.getMessageUtils();

        // Map slot to permission
        int[] permSlots = {4, 10, 11, 12, 13, 14, 15, 16, 21, 23};
        int[] permIndices = {Team.PERM_ECHEST, Team.PERM_HOMES, Team.PERM_INVITE, Team.PERM_PVP,
                Team.PERM_TELEPORT, Team.PERM_CHAT, Team.PERM_RENAME, Team.PERM_SETDISPLAYNAME,
                Team.PERM_MANAGEALLY, Team.PERM_MANAGEMEMBERS};

        for (int i = 0; i < permSlots.length; i++) {
            if (slot == permSlots[i]) {
                boolean current = team.hasPerm(targetId, permIndices[i]);
                team.setPerm(targetId, permIndices[i], !current);
                plugin.getTeamManager().saveTeam(team);
                // Re-open editor
                new PlayerEditorGUI(plugin, player, team, targetId).open();
                return;
            }
        }

        int kickSlot = plugin.getConfig().getInt("gui.team-editor-gui.items.kick.slot", 26);
        int backSlot = plugin.getConfig().getInt("gui.team-editor-gui.items.back.slot", 18);

        if (slot == kickSlot) {
            plugin.getChatManager().disableTeamChat(targetId);
            plugin.getTeamManager().removeMember(team, targetId);
            Player target = Bukkit.getPlayer(targetId);
            if (target != null) {
                msg.send(target, msg.getRaw("kicked", "%team%", team.getName()));
                plugin.getSoundManager().playTeamKick(target);
            }
            player.closeInventory();
            plugin.getTeamGUI().open(player, 0);
        } else if (slot == backSlot) {
            player.closeInventory();
            plugin.getTeamGUI().open(player, 0);
        }
    }

    private void handleDisbandGUIClick(InventoryClickEvent event, Player player) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        plugin.getSoundManager().playGuiClick(player);

        int cancelSlot = plugin.getConfig().getInt("gui.disband-gui.items.cancel.slot", 11);
        int confirmSlot = plugin.getConfig().getInt("gui.disband-gui.items.confirm.slot", 15);

        Team team = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
        if (team == null) { player.closeInventory(); return; }

        if (slot == confirmSlot) {
            String teamName = team.getName();
            for (UUID memberId : team.getMembers()) {
                Player member = Bukkit.getPlayer(memberId);
                if (member != null && !member.equals(player)) {
                    plugin.getMessageUtils().send(member, plugin.getMessageUtils().getRaw("team-disbanded", "%team%", teamName));
                    plugin.getChatManager().disableTeamChat(memberId);
                }
            }
            plugin.getChatManager().disableTeamChat(player.getUniqueId());
            plugin.getTeamManager().disbandTeam(team);
            player.closeInventory();
            plugin.getMessageUtils().sendMsg(player, "team-disbanded", "%team%", teamName);
            plugin.getSoundManager().playTeamDisband(player);
        } else if (slot == cancelSlot) {
            player.closeInventory();
        }
    }

    private void handleAllyGUIClick(InventoryClickEvent event, Player player) {
        event.setCancelled(true);
        int slot = event.getRawSlot();
        plugin.getSoundManager().playGuiClick(player);

        Team myTeam = plugin.getTeamManager().getTeamByPlayer(player.getUniqueId());
        if (myTeam == null) { player.closeInventory(); return; }

        MessageUtils msg = plugin.getMessageUtils();

        // Get all teams in same order as GUI
        java.util.List<Team> allTeams = new java.util.ArrayList<>(plugin.getTeamManager().getAllTeams());
        allTeams.removeIf(t -> t.getTeamId().equals(myTeam.getTeamId()));

        if (slot < allTeams.size()) {
            Team targetTeam = allTeams.get(slot);

            if (myTeam.isAlly(targetTeam.getTeamId())) {
                // Shift-click to remove ally
                if (event.isShiftClick()) {
                    plugin.getTeamManager().removeAlly(myTeam, targetTeam);
                    msg.send(player, msg.getRaw("notify_remove_ally", "%team%", targetTeam.getName()));
                    // Notify other team
                    for (UUID memberId : targetTeam.getMembers()) {
                        Player member = Bukkit.getPlayer(memberId);
                        if (member != null) {
                            msg.send(member, msg.getRaw("notify_remove_ally", "%team%", myTeam.getName()));
                        }
                    }
                    player.closeInventory();
                    new TeamAllyGUI(plugin, player, 0).open();
                }
            } else if (plugin.getTeamManager().getDb().hasAllyRequest(targetTeam.getTeamId(), myTeam.getTeamId())) {
                // Accept their request
                if (myTeam.getAllies().size() >= 9) {
                    msg.send(player, msg.getRaw("notify_limit_ally"));
                    return;
                }
                plugin.getTeamManager().addAlly(myTeam, targetTeam);
                msg.send(player, msg.getRaw("notify_accept_ally", "%team%", targetTeam.getName()));
                player.closeInventory();
                new TeamAllyGUI(plugin, player, 0).open();
            } else if (!plugin.getTeamManager().getDb().hasAllyRequest(myTeam.getTeamId(), targetTeam.getTeamId())) {
                // Send request
                if (!myTeam.hasPerm(player.getUniqueId(), Team.PERM_MANAGEALLY)) {
                    msg.send(player, msg.getRaw("notify_only_owner_ally"));
                    return;
                }
                if (myTeam.getAllies().size() >= 9) {
                    msg.send(player, msg.getRaw("notify_limit_ally"));
                    return;
                }
                plugin.getTeamManager().getDb().addAllyRequest(myTeam.getTeamId(), targetTeam.getTeamId());
                msg.send(player, msg.getRaw("notify_request_ally", "%team%", targetTeam.getName()));
                player.closeInventory();
                new TeamAllyGUI(plugin, player, 0).open();
            }
        }
    }

    private void handleEchestClick(InventoryClickEvent event, Player player, TeamEchestGUIHolder holder) {
        int slot = event.getRawSlot();
        int guiSize = plugin.getConfig().getInt("gui.team-echest.size", 36);
        int contentSlots = (plugin.getConfig().getInt("gui.team-echest.content.end-col", 8) -
                plugin.getConfig().getInt("gui.team-echest.content.start-col", 0) + 1) *
                plugin.getConfig().getInt("gui.team-echest.content.rows", 3);

        if (slot >= contentSlots && slot < guiSize) {
            // Clicked a control button
            event.setCancelled(true);
            plugin.getSoundManager().playGuiClick(player);

            int backSlot = plugin.getConfig().getInt("gui.team-echest.custom-items.back.slot", 27);
            if (slot == backSlot) {
                player.closeInventory();
                plugin.getTeamGUI().open(player, 0);
            }
        } else if (slot >= guiSize) {
            // Clicking player's own inventory while echest is open - allow item movement
        }
        // Content slots: allow normal interaction (items are saved on close)
    }
}
