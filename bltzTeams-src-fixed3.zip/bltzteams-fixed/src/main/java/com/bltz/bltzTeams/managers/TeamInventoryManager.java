package com.bltz.bltzTeams.managers;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.database.DatabaseProvider;
import com.bltz.bltzTeams.models.Team;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TeamInventoryManager {

    private final BltzTeams plugin;
    private final DatabaseProvider db;
    private final Map<UUID, ItemStack[]> cache = new HashMap<>();

    public TeamInventoryManager(BltzTeams plugin, DatabaseProvider db) {
        this.plugin = plugin;
        this.db = db;
    }

    public ItemStack[] getTeamEchest(Team team) {
        return cache.computeIfAbsent(team.getTeamId(), id -> {
            ItemStack[] items = db.getTeamEchestItems(id);
            if (items == null) {
                int size = plugin.getConfig().getInt("gui.team-echest.size", 36);
                items = new ItemStack[size];
            }
            return items;
        });
    }

    public void saveTeamEchest(Team team, ItemStack[] items) {
        cache.put(team.getTeamId(), items);
        db.setTeamEchestItems(team.getTeamId(), items);
    }

    public void clearCache(UUID teamId) {
        cache.remove(teamId);
    }
}
