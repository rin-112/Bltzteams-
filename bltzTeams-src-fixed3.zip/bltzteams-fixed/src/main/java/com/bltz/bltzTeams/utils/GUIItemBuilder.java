package com.bltz.bltzTeams.utils;

import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

public class GUIItemBuilder {

    private Material material;
    private String name;
    private final List<String> lore = new ArrayList<>();
    private OfflinePlayer skullOwner;

    public GUIItemBuilder(Material material) {
        this.material = material;
    }

    public GUIItemBuilder name(String name) {
        this.name = MessageUtils.colorize(name);
        return this;
    }

    public GUIItemBuilder lore(List<String> lore) {
        for (String line : lore) {
            this.lore.add(MessageUtils.colorize(line));
        }
        return this;
    }

    public GUIItemBuilder lore(String... lines) {
        for (String line : lines) {
            this.lore.add(MessageUtils.colorize(line));
        }
        return this;
    }

    public GUIItemBuilder skullOwner(OfflinePlayer player) {
        this.material = Material.PLAYER_HEAD;
        this.skullOwner = player;
        return this;
    }

    public ItemStack build() {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        if (name != null) meta.setDisplayName(name);
        if (!lore.isEmpty()) meta.setLore(lore);
        if (skullOwner != null && meta instanceof SkullMeta skull) {
            skull.setOwningPlayer(skullOwner);
        }
        item.setItemMeta(meta);
        return item;
    }

    public static ItemStack fillItem(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }
}
