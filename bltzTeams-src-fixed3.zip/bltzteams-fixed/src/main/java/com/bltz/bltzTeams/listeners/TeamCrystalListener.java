package com.bltz.bltzTeams.listeners;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;

public class TeamCrystalListener implements Listener {

    private final BltzTeams plugin;

    public TeamCrystalListener(BltzTeams plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) {
            // Check crystal
            return;
        }

        Team victimTeam = plugin.getTeamManager().getTeamByPlayer(victim.getUniqueId());
        Team attackerTeam = plugin.getTeamManager().getTeamByPlayer(attacker.getUniqueId());

        if (victimTeam == null || attackerTeam == null) return;

        // Same team check
        if (victimTeam.getTeamId().equals(attackerTeam.getTeamId())) {
            if (!victimTeam.isPvpEnabled()) {
                event.setCancelled(true);
                return;
            }
        }

        // Ally check
        if (victimTeam.isAlly(attackerTeam.getTeamId())) {
            if (!victimTeam.allyPvpEnabled(attackerTeam.getTeamId())) {
                event.setCancelled(true);
            }
        }
    }
}
