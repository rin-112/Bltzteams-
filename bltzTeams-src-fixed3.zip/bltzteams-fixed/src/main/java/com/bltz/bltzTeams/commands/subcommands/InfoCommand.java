package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class InfoCommand extends SubCommand {

    public InfoCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "info"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        Team team;
        if (args.length > 0) {
            // Look up other player's team
            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                msg.send(player, msg.getRaw("player-not-exist"));
                return;
            }
            team = tm.getTeamByPlayer(target.getUniqueId());
            if (team == null) {
                msg.send(player, msg.getRaw("not-in-team"));
                return;
            }
        } else {
            team = tm.getTeamByPlayer(player.getUniqueId());
            if (team == null) {
                msg.send(player, msg.getRaw("not-in-team"));
                return;
            }
        }

        // Open Info GUI
        new com.bltz.bltzTeams.gui.TeamInfoGUI(plugin, player, team).open();
    }
}
