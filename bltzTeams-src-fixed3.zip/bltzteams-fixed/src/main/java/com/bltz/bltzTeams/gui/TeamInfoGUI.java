package com.bltz.bltzTeams.gui;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.GUIItemBuilder;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TeamInfoGUI {

    private final BltzTeams plugin;
    private final Player player;
    private final Team team;
    private static final int GUI_SIZE = 54;

    public TeamInfoGUI(BltzTeams plugin, Player player, Team team) {
        this.plugin = plugin;
        this.player = player;
        this.team = team;
    }

    public void open() {
        String title = MessageUtils.colorize(
                plugin.getConfig().getString("gui.team-info-gui.title", "Team Info - %team%")
                        .replace("%team%", team.getName()));
        Inventory inv = Bukkit.createInventory(new InfoGUIHolder(), GUI_SIZE, title);

        // Fill
        ItemStack fill = GUIItemBuilder.fillItem(Material.GRAY_STAINED_GLASS_PANE);
        for (int i = 45; i < GUI_SIZE; i++) inv.setItem(i, fill);

        // Member heads
        List<UUID> members = new ArrayList<>(team.getMembers());
        for (int i = 0; i < Math.min(members.size(), 45); i++) {
            UUID memberId = members.get(i);
            OfflinePlayer op = Bukkit.getOfflinePlayer(memberId);
            String name = op.getName() != null ? op.getName() : "Unknown";
            String role = team.isOwner(memberId) ?
                    plugin.getConfig().getString("gui.team-info-gui.defaults.role-owner", "&c[Owner]") :
                    plugin.getConfig().getString("gui.team-info-gui.defaults.role-member", "&7Member");
            String status = Bukkit.getPlayer(memberId) != null ?
                    plugin.getConfig().getString("gui.team-info-gui.defaults.status-online", "&aOnline") :
                    plugin.getConfig().getString("gui.team-info-gui.defaults.status-offline", "&cOffline");

            List<String> lore = new ArrayList<>();
            for (String line : plugin.getConfig().getStringList("gui.team-info-gui.items.member-head.lore")) {
                lore.add(line.replace("%role%", role).replace("%status%", status).replace("%player%", name));
            }
            inv.setItem(i, new GUIItemBuilder(Material.PLAYER_HEAD)
                    .skullOwner(op)
                    .name("&f" + name)
                    .lore(lore).build());
        }

        // Info item
        int infoSlot = plugin.getConfig().getInt("gui.team-info-gui.items.info.slot", 49);
        inv.setItem(infoSlot, new GUIItemBuilder(Material.IRON_HELMET)
                .name(plugin.getConfig().getString("gui.team-info-gui.items.info.name", "&eTeam %team%").replace("%team%", team.getName()))
                .lore(plugin.getConfig().getStringList("gui.team-info-gui.items.info.lore")
                        .stream().map(l -> l.replace("%owner%", team.getOwnerName())
                                .replace("%members%", String.valueOf(team.getMemberCount())))
                        .toList())
                .build());

        // Home item
        int homeSlot = plugin.getConfig().getInt("gui.team-info-gui.items.home.slot", 52);
        boolean hasHome = team.getHome() != null;
        List<String> homeLore = hasHome ?
                plugin.getConfig().getStringList("gui.team-info-gui.items.home.lore") :
                plugin.getConfig().getStringList("gui.team-info-gui.items.home.no-home");
        inv.setItem(homeSlot, new GUIItemBuilder(Material.WHITE_BANNER)
                .name(plugin.getConfig().getString("gui.team-info-gui.items.home.name", "&eTeam Home"))
                .lore(homeLore).build());

        player.openInventory(inv);
    }
}
