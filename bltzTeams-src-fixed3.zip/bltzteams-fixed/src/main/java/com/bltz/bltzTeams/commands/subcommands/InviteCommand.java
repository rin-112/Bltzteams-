package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class InviteCommand extends SubCommand {

    public InviteCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "invite"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-invite"));
            return;
        }

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (!team.hasPerm(player.getUniqueId(), Team.PERM_INVITE)) {
            msg.send(player, msg.getRaw("no-permission"));
            plugin.getSoundManager().playError(player);
            return;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null) {
            msg.send(player, msg.getRaw("player-not-exist"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (tm.isInTeam(target.getUniqueId())) {
            msg.send(player, msg.getRaw("already-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        if (team.getMemberCount() >= plugin.getConfigUtils().getMaxMembers()) {
            msg.send(player, msg.getRaw("team-full", "%max%", String.valueOf(plugin.getConfigUtils().getMaxMembers())));
            plugin.getSoundManager().playError(player);
            return;
        }

        plugin.getInviteManager().addInvite(target.getUniqueId(), team.getTeamId());

        msg.sendMsg(player, "player-invited", "%player%", target.getName());
        msg.send(target, msg.getRaw("invite-received", "%team%", team.getName()));
        plugin.getSoundManager().playTeamInvite(player);
        plugin.getSoundManager().playTeamInvite(target);
    }
}
