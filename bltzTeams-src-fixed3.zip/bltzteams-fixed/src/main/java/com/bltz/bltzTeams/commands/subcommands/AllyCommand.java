package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.gui.TeamAllyGUI;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;

public class AllyCommand extends SubCommand {

    public AllyCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "ally"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        Team team = tm.getTeamByPlayer(player.getUniqueId());
        if (team == null) {
            msg.send(player, msg.getRaw("not-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        // Open ally GUI
        new TeamAllyGUI(plugin, player, 0).open();
    }
}
