package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class JoinCommand extends SubCommand {

    public JoinCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "join"; }

    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        TeamManager tm = plugin.getTeamManager();

        if (args.length < 1) {
            msg.send(player, msg.getRaw("usage-join"));
            return;
        }

        if (tm.isInTeam(player.getUniqueId())) {
            msg.send(player, msg.getRaw("already-in-team"));
            plugin.getSoundManager().playError(player);
            return;
        }

        String teamName = args[0];
        Team team = tm.getTeamByName(teamName);

        if (team == null) {
            msg.send(player, msg.getRaw("team-not-found", "%team%", teamName));
            plugin.getSoundManager().playError(player);
            return;
        }

        // Check if invited
        if (!plugin.getInviteManager().hasInvite(player.getUniqueId(), team.getTeamId())) {
            msg.send(player, msg.getRaw("not-invited"));
            plugin.getSoundManager().playError(player);
            return;
        }

        // Check max members
        int maxMembers = plugin.getConfigUtils().getMaxMembers();
        if (team.getMemberCount() >= maxMembers) {
            msg.send(player, msg.getRaw("team-full", "%max%", String.valueOf(maxMembers)));
            plugin.getSoundManager().playError(player);
            return;
        }

        plugin.getInviteManager().removeInvite(player.getUniqueId(), team.getTeamId());
        tm.addMember(team, player.getUniqueId());

        msg.sendMsg(player, "team-joined", "%team%", team.getName());
        plugin.getSoundManager().playTeamJoin(player);

        // Notify team members
        for (Player member : Bukkit.getOnlinePlayers()) {
            if (team.hasMember(member.getUniqueId()) && !member.equals(player)) {
                msg.send(member, msg.getRaw("player-joined-team", "%player%", player.getName()));
            }
        }
    }
}
