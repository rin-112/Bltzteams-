package com.bltz.bltzTeams.commands.adminsubcommands;
import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;
public class AdminChatSpyCommand extends AdminSubCommand {
    public AdminChatSpyCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "chatspy"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        plugin.getChatManager().toggleChatSpy(player.getUniqueId());
        if (plugin.getChatManager().isChatSpy(player.getUniqueId())) {
            msg.send(player, msg.getRaw("admin-chatspy-enabled"));
        } else {
            msg.send(player, msg.getRaw("admin-chatspy-disabled"));
        }
    }
}
