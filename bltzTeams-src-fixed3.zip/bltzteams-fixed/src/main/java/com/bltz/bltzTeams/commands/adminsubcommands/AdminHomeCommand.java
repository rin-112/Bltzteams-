package com.bltz.bltzTeams.commands.adminsubcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.AdminSubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AdminHomeCommand extends AdminSubCommand {
    public AdminHomeCommand(BltzTeams p) { super(p); }
    @Override public String getName() { return "home"; }
    @Override
    public void execute(Player player, String[] args) {
        MessageUtils msg = plugin.getMessageUtils();
        if (args.length < 1) { msg.send(player, msg.getRaw("usage-admin-home")); return; }
        Team team = plugin.getTeamManager().getTeamByName(args[0]);
        if (team == null) { msg.send(player, msg.getRaw("team-not-found", "%team%", args[0])); return; }
        if (team.getHome() == null) { msg.send(player, msg.getRaw("admin-no-home-set", "%team%", args[0])); return; }
        player.teleport(team.getHome());
        msg.send(player, msg.getRaw("admin-teleport-success", "%team%", args[0]));
    }
}
