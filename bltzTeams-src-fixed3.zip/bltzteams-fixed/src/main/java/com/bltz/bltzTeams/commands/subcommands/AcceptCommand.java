package com.bltz.bltzTeams.commands.subcommands;

import com.bltz.bltzTeams.BltzTeams;
import com.bltz.bltzTeams.commands.SubCommand;
import com.bltz.bltzTeams.managers.TeamManager;
import com.bltz.bltzTeams.models.Team;
import com.bltz.bltzTeams.utils.MessageUtils;
import org.bukkit.entity.Player;

public class AcceptCommand extends SubCommand {

    public AcceptCommand(BltzTeams plugin) {
        super(plugin);
    }

    @Override
    public String getName() { return "accept"; }

    @Override
    public void execute(Player player, String[] args) {
        // Handled through GUI - this command isn't needed but kept for compatibility
        plugin.getMessageUtils().send(player, "&cPlease use the Ally GUI (/team ally) to manage ally requests.");
    }
}
